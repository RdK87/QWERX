# -*- coding: utf-8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf8')
import re
import requests,urllib
from resources.lib.libraries import client
import json
import xbmc

class WizjaTvApi():

    def __init__(self):
        self.MAIN_URL = 'http://wizja.tv/'
        self.DEFAULT_ICON_URL = 'http://wizja.tv/logo.png'
        self.HTTP_HEADER = {'User-Agent': 'Mozilla/5.0', 'Accept': 'text/html'}
        self.AJAX_HEADER = dict(self.HTTP_HEADER)
        self.AJAX_HEADER.update({'X-Requested-With': 'XMLHttpRequest'})

        self.COOKIE_FILE = 'F:/wizjatv.cookie'

        self.http_params = {}
        self.http_params.update(
            {'header': self.HTTP_HEADER} )
        self.loggedIn = False


    def doLogin(self,login,password,s):
        logged = False
        premium = False
        loginUrl = 'http://wizja.tv/users/index.php'

        HTTP_HEADER = dict(self.HTTP_HEADER)
        HTTP_HEADER.update({'Referer': loginUrl})
        params = dict(self.http_params)
        params['header'] = HTTP_HEADER

        post_data = {'user_name': login, 'user_password': password, 'login': 'Zaloguj'}
        data = postUrlRequestData(loginUrl, s, post_data, False)
        data = data.text
        #print data
        if data:
            if '?logout' in data:
                print ('WizjaTvApi.doLogin login as [%s]' % login)
                logged = True
                if 'Premium aktywne do ' in data:
                    premium = True
            else:
                print ('WizjaTvApi.doLogin login failed - wrong user or password? %s' % login)
        return logged, premium


    def getList(self,login,password,s):
        #print ("WizjaTvApi.getChannelsList")
        import requests
        s = requests.Session()
        if login != '' and password != '':
            ret = self.doLogin(login, password,s)
            if ret[0]:
                self.loggedIn = True
                if not ret[1]:
                    print 'Użytkownika "%s" zalogowany poprawnie. Brak premium!' % login
                    return []
            else:
                print 'Problem z zalogowanie użytkownika "%s". Sprawdź dane do logowania w konfiguracji hosta.' % login
                self.loggedIn = False
                return []
        else:
            #print 'Serwis ten wymaga zalogowania. Wprowadź swój login i hasło w konfiguracji hosta dostępnej po naciśnięciu niebieskiego klawisza.'
            return []

        channelsTab = []

        #data = s.get("http://wizja.tv/")
        data = getUrlRequestData("http://wizja.tv/",s,False)
        data = client.parseDOM(data.text, 'ul', attrs={'class': 'dropdown-menu'})[0]
        linki = client.parseDOM(data, 'a', ret='href')
        ikony = client.parseDOM(data, 'img', ret='src')
        for tuple in zip(linki,ikony):
            icon = str("http://wizja.tv/" + tuple[1])
            url = str("http://wizja.tv/" + tuple[0])
            title = icon.split('/')[-1][:-4].upper()

            params = {'name': 'wizja.tv',
                      'type': 'video',
                      'title': title,
                      'url': url,
                      'icon': icon}
            channelsTab.append(params)

        return s,channelsTab


    def getVideoLink(self, url,s):
        xbmc.log(msg="WizjaTvApi.getVideoLink", level=xbmc.LOGNOTICE)
        urlsTab = []

        data = getUrlRequestData(url,s,False).text
        data = client.parseDOM(data, 'iframe', ret='src')
        xbmc.log(msg=str(data), level=xbmc.LOGNOTICE)
        for url in data:
            HTTP_HEADER = dict(self.HTTP_HEADER)
            HTTP_HEADER.update({'Referer': url})
            params = dict(self.http_params)
            params['header'] = HTTP_HEADER

            tries = 0
            while tries < 2:
                tries += 1

                if 'porter' in url or 'player' in url:
                    tmp = getUrlRequestData("http://wizja.tv/" + url, s, False).text
                    #print(tmp)
                    videoUrl = re.search("""src: "(.*)\"""",str(tmp))
                    try:
                        videoUrl = videoUrl.group(1)
                        videoUrl = urllib.unquote(videoUrl).decode('utf8')
                    except:
                        videoUrl = ''
                    killUrl = re.search("""<a href="(.*)" target="_top">Z""", str(tmp))
                    try:
                        killUrl = killUrl.group(1)
                        killUrl = urllib.unquote(killUrl).decode('utf8')
                    except:
                        killUrl = ''
                    if videoUrl != '':
                        urlTab = re.search("""rtmp:\/\/([^\/]+?)\/([^\/]+?)\/([^\/]+?)\?(.+?)&streamType""", str(videoUrl))

                        rtmp = 'rtmp://$OPT:rtmp-raw=rtmp://' + urlTab.group(1) + '/' + urlTab.group(2) + '?' + urlTab.group(4) + \
                               ' playpath=' + urlTab.group(3) + '?' + urlTab.group(4) + \
                               ' app=' + urlTab.group(2) + '?' + urlTab.group(4) + \
                               ' swfVfy=0 flashver=LNX\\25,0,0,12 timeout=25 swfUrl=https://wizja.tv/player/StrobeMediaPlayback_v4.swf live=true pageUrl=https://wizja.tv/' + \
                               str(url).replace("porter.php","watch.php")
                        xbmc_rtmp = 'rtmp://$OPT:rtmp-raw=rtmp://' + urlTab.group(1) + '/' + urlTab.group(2) + '?' + urlTab.group(4) + \
                               ' app=' + urlTab.group(2) + '?' + urlTab.group(4) + \
                               ' playpath=' + urlTab.group(3) + '?' + urlTab.group(4) + \
                               ' swfVfy=1 flashver=LNX\\25,0,0,12 timeout=25 ' \
                               'swfUrl=https://wizja.tv/player/StrobeMediaPlayback_v5.swf live=true ' \
                               'pageUrl=https://wizja.tv/' + str(url).replace("porter.php?ch","watch.php?id")
                        urlsTab.append({'name': 'rtmp', 'url': xbmc_rtmp})
                    else:
                        #s.get("http://wizja.tv/" + killUrl, headers = HTTP_HEADER)
                        getUrlRequestData("http://wizja.tv/" + killUrl,s,False)
                        continue
                break
        return urlsTab

obj = WizjaTvApi()

us = []
ps = []

# Konta

us.append('jacques')
ps.append('jacques')

us.append('elzbieta1969')
ps.append('elzbieta1969')

us.append('aneta3011')
ps.append('nadia2010')

us.append('antc111@gmail.com')
ps.append('kurwamac12')

us.append('basia5')
ps.append('basia5')

us.append('sonia1989')
ps.append('makador123')

us.append('xenik')
ps.append('retusz961')

us.append('geto90')
ps.append('Geto1990')

us.append('wojtek92')
ps.append('wojtek92')

us.append('taochern')
ps.append('nklfs99')

us.append('renkus')
ps.append('linkin1')

us.append('mariuszek32')
ps.append('kamilek8')

us.append('tomekh18')
ps.append('hryszko18')

us.append('robertjapan73@wp.pl')
ps.append('slayer666')

us.append('grzywacz182')
ps.append('grzywacz1988')

us.append('tomsend212')
ps.append('wios1981')

us.append('mitos1@o2.pl')
ps.append('mitos6451753')

us.append('dorotka30')
ps.append('dorotka30')

us.append('osska1802@wp.pl')
ps.append('ramzes17')

us.append('m4gz')
ps.append('q1w2e3r4')

us.append('irek3769')
ps.append('krystian9')

us.append('malwinkaa89')
ps.append('andrzej83')

us.append('pszim@wp.pl')
ps.append('edvin1')

us.append('vip301')
ps.append('302150')

def ListaKanalow(k):
    global s
    s=k
    for dane in zip(us,ps):
        try:
            k,channelList = obj.getList(dane[0], dane[1],s)
            s=k
        except:
            continue
        if len(channelList)<2:
            continue
        else:
            return s,json.dumps(channelList)

def Link(url,s):
    link = obj.getVideoLink(url,s)
    wynik = link[0]['url']
    return str(wynik)

def getUrlRequestData(url,s,proxy = False):
    proxyDict = {
        "http" : "66.70.147.195:3128",
    }
    if proxy:
        #142.44.240.106:80
        #31.182.52.156:3129
        #145.239.92.106:3128
        r = s.get(url,proxies = proxyDict)
        return r
    else:
        r = s.get(url)
        return r

def postUrlRequestData(url,s,data,proxy = False):
    proxyDict = {
        "http" : "66.70.147.195:3128",
    }
    if proxy:
        #31.182.52.156:3129
        #145.239.92.106:3128
        r = s.post(url,data = data,proxies = proxyDict)
        return r
    else:
        r = s.post(url,data = data)
        return r