# -*- coding: UTF-8 -*-
import urllib, urllib2, re, xbmc, xbmcplugin, xbmcgui, xbmc, xbmcaddon, HTMLParser, os
import requests
from resources.lib.libraries import source_utils, dom_parser, client, cleantitle
import wizja
import sys

reload(sys)
sys.setdefaultencoding('utf8')
s = requests.Session()
xbmcplugin.setContent(int(sys.argv[1]), 'movies')

def CATEGORIES():
    WizjaTV()

def addDir(name, url, mode, iconimage, thumb, opis, isFolder=True, total=1):
    u=sys.argv[0]+'?url='+urllib.quote_plus(url)+'&mode='+str(mode)+'&name='+urllib.quote_plus(name)+'&iconimage='+urllib.quote_plus(iconimage)
    ok = True
    liz = xbmcgui.ListItem(name, iconimage, thumbnailImage=thumb)
    url = thumb
    liz.setArt({'thumb': thumb,
                'icon': iconimage,
                'fanart': url})
    liz.setInfo("Video", {'title':name , 'genre':'Anime', 'rating': 0, 'plot': opis})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder, totalItems=total)
    return ok

def WizjaTV():
    import json
    import requests
    s = requests.Session()
    s,content = wizja.ListaKanalow(s)
    content = json.loads(content)
    for item in content:
        addDir(item['title'],item['url'] , 6, item['icon'],'','', False)

def odpalanieLinku():
    s = requests.Session()
    url = urllib.unquote_plus(params['url'])
    #import pydevd
    #pydevd.settrace(stdoutToServer=True, stderrToServer=True)
    s,content = wizja.ListaKanalow(s) # zeby odświeży sesje
    url = wizja.Link(url,s)
    xbmc.Player().play(str(url).replace("rtmp://$OPT:rtmp-raw=", ""))

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2 :
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/') :
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)) :
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]                  
    return param

params = get_params()
url = None
name = None
thumb = None
mode = None
iconimage = None

try:
    url = urllib.unquote_plus(params['url'])
except:
    pass
try:
    name = urllib.unquote_plus(params['name'])
except:
    pass
try:
    mode = int(params['mode'])
except:
    pass
try:        
    iconimage = urllib.unquote_plus(params['iconimage'])
except:
    pass

if mode == None :
    CATEGORIES()
elif mode == 6 : 
    odpalanieLinku()

xbmcplugin.endOfDirectory(int(sys.argv[1]))