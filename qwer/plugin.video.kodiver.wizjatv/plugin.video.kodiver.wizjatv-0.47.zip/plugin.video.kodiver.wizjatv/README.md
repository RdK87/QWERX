plugin.video.kodiver.wizjatv
============================

[![Build Status](https://travis-ci.org/kodiver/plugin.video.kodiver.wizjatv.svg?branch=master)](https://travis-ci.org/kodiver/plugin.video.kodiver.wizjatv)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/57d4b5bc1bc04120b0ec23b3ea7708a5)](https://www.codacy.com/app/gmaslowski/plugin.video.kodiver.wizjatv?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=kodiver/plugin.video.kodiver.wizjatv&amp;utm_campaign=Badge_Grade)

## Are you using? Please support
[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=GDSUZAHNZSDPW&lc=PL&item_name=kodiver&item_number=kodiver%2dplugins&currency_code=PLN&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted)
