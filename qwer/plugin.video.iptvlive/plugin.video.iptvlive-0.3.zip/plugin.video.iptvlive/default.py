# -*- coding: utf-8 -*

import util, urllib,urllib2, xbmcplugin, xbmcaddon, xbmcgui, re, sys, os
import json
ADDON_ID = 'plugin.video.iptvlive'
BASEURL = 'http://xbmc.iptvlive.org/'


__addon__ = xbmcaddon.Addon(id=ADDON_ID)
EMAIL = __addon__.getSetting("email")
PASS = __addon__.getSetting("pass")

tvt = xbmcaddon.Addon()
pDialog = xbmcgui.DialogProgress()
dialog = xbmcgui.Dialog()

def playAudio(params):
        url = params['audioUrl']
        title = params['station']
        img_src = params['logo']
        
        li = xbmcgui.ListItem(label=title, iconImage=img_src, thumbnailImage=img_src)
        li.setInfo(type='Audio', infoLabels={ "Title": title })
        xbmc.Player().play(item=url, listitem=li)

def search(params):

    searchStr = ''
    keyboard = xbmc.Keyboard(searchStr,'Search')
    keyboard.doModal()

    if (keyboard.isConfirmed() == False):
        return mainMenu()
    searchStr = keyboard.getText().replace(' ','+')  # sometimes you need to replace spaces with + or %20
    if len(searchStr) == 0:
        return mainMenu()
    else:
    
        url = 'http://xbmc.iptvlive.org/search.php?search=' + searchStr
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'XBMC - PL RADIO')
        response = urllib2.urlopen(req)
        obj_data = json.load(response)

        for s in range(len(obj_data)):
            params = {'play':1,
                      'station':obj_data[s]['stationName'],
                      'audioUrl':obj_data[s]['stationURL'],
                      'logo':obj_data[s]['stationLogo']}
            link = util.makeLink(params)
            name = obj_data[s]['stationName']
            img_src = obj_data[s]['stationLogo']
            util.addMenuItem(name, link, img_src, '', True, None, '')
        
        
        util.endListing()

		#Get TV List
def categoryTVList(params):
    category = params['category']
		
    url = 'http://xbmc.iptvlive.org/getTVStations.php?category=' + urllib.quote(category) + '&pass=' + PASS + '&email=' + EMAIL
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - IPTVLIVE')
    response = urllib2.urlopen(req)

    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'play':1,
                  'station':obj_data[s]['stationName'],
                  'audioUrl':obj_data[s]['stationURL'],
                  'logo':obj_data[s]['stationLogo']}
        link = util.makeLink(params)
        name = obj_data[s]['stationName']
        img_src = obj_data[s]['stationLogo']

        util.addMenuItem(name, link, img_src, '', True, None, '')
        
        
    util.endListing()



#Get TV categories
def getTVCategories():
    url = 'http://xbmc.iptvlive.org/getTVCategories.php'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - PL RADIO')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'categoryTVList':1,
                  'category':obj_data[s]['categoryName']}
        link = util.makeLink(params)
        name = obj_data[s]['categoryName']
        img_src = obj_data[s]['categoryLogo']
        fan_art = obj_data[s]['categoryFanArt']

        name = name.decode('utf-8')
        util.addMenuItem(name, link, img_src, '', True, None, fan_art)
        
        
    util.endListing()
			

#Show Alpha
def showAlpha():
    param = {'showMoviesByLetter':1, 'letter':'number', 'start':0}
    link = util.makeLink(param)
    util.addMenuItem('#123', link, '', setIcon('letters/1'), True, None, '')
    
    for code in range(ord('A'), ord('Z')+1):
      param = {'showMoviesByLetter':1, 'letter':unichr(code), 'start':0}
      link = util.makeLink(param)
      icon = setIcon('letters/' + chr(code));
      util.addMenuItem(chr(code), link, '', icon, True, None, '')
      
    util.endListing()

def showMoviesByLetter(params):
    letter = params['letter']
    start = params['start']
    url = 'http://xbmc.iptvlive.org/getMoviesListByLetter.php?letter=' + urllib.quote(letter) + '&start=' + start + '&pass=' + PASS + '&email=' + EMAIL

    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - IPTVLIVE')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)
    
    
    for s in range(len(obj_data['movies'])):
        name = obj_data['movies'][s]['movieName']
        url = obj_data['movies'][s]['movieURL']
        img_src = obj_data['movies'][s]['movieCover']
        fan_art = obj_data['movies'][s]['movieFanArt']
        genre = obj_data['movies'][s]['movieGenre'],
        year = obj_data['movies'][s]['movieYear'],
        cast = obj_data['movies'][s]['movieCast'],
        director = obj_data['movies'][s]['movieDirector'],
        plot = obj_data['movies'][s]['moviePlot'],
        duration = obj_data['movies'][s]['movieDuration'],
        trailer = obj_data['movies'][s]['movieTrailer'],
        rating = obj_data['movies'][s]['movieRating'],
        params = {'play':1,
                  'station':name,
                  'audioUrl':url,
                  'logo':img_src,
                  }
        link = util.makeLink(params)
        
        util.addMovieItem(name, link, img_src, '', True, genre, year, cast, director, plot, duration, trailer, None, rating)
    
    if obj_data['more']['start'] != 0:
        params = {'showMoviesByLetter':1,
                  'letter':letter,
                  'start':obj_data['more']['start']}
        link = util.makeLink(params)
        util.addMenuItem(u'Następne', link, '', setIcon('next'), True, None, '')
    util.endListing()    

      
#Get Movies categories
def getMoviesCategories():
    url = 'http://xbmc.iptvlive.org/getMoviesCategories.php'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - IPTVLIVE')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)
    
    param = {'moviesAlpha':1}
    link = util.makeLink(param)
    util.addMenuItem('Alfabetycznie', link, '', setIcon('movies'), True, None, '')
    
    param = {'searchMovies':1,'search':0, 'start':0}
    link = util.makeLink(param)
    util.addMenuItem('Szukaj Filmu', link, '', setIcon('search'), True, None, '')
    
    param = {'searchActor':1,'search':0, 'start':0}
    link = util.makeLink(param)
    util.addMenuItem('Szukaj Aktora', link, '', setIcon('search'), True, None, '')

        
    for s in range(len(obj_data)):
        params = {'getMoviesByCategory':1,
                  'categoryID':obj_data[s]['categoryID'],
                  'start':0}
        link = util.makeLink(params)
        name = obj_data[s]['categoryName']
        img_src = obj_data[s]['categoryLogo']
        fan_art = obj_data[s]['categoryFanArt']
        util.addMenuItem(name, link, img_src, '', True, None, fan_art)
    
    
        
    util.endListing()

#Get List of Movies by category
def getMoviesByCategory(params):
    xbmc.executebuiltin('Container.SetViewMode(61)')
    category = params['categoryID']

    start = params['start']
    url = 'http://xbmc.iptvlive.org/getMoviesByCategory.php?categoryID=' + category + '&start=' + start + '&pass=' + PASS + '&email=' + EMAIL
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - IPTVLIVE')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)
    

        
    for s in range(len(obj_data['movies'])):
        name = obj_data['movies'][s]['movieName']
        url = obj_data['movies'][s]['movieURL']
        img_src = obj_data['movies'][s]['movieCover']
        fan_art = obj_data['movies'][s]['movieFanArt']
        genre = obj_data['movies'][s]['movieGenre'],
        year = obj_data['movies'][s]['movieYear'],
        cast = obj_data['movies'][s]['movieCast'],
        director = obj_data['movies'][s]['movieDirector'],
        plot = obj_data['movies'][s]['moviePlot'],
        duration = obj_data['movies'][s]['movieDuration'],
        trailer = obj_data['movies'][s]['movieTrailer'],
        rating = obj_data['movies'][s]['movieRating'],
        #caption, link, icon=None, thumbnail=None, folder=False, duration=None, fanart=None
        params = {'play':1,
                  'station':name,
                  'audioUrl':url,
                  'logo':img_src,
                  }
        link = util.makeLink(params)
        #title, link, icon=None, thumbnail=None, folder=False, genre=None, year=None, cast=None, director=None, plot=None, duration=None, trailer=None, fanart=None):
        util.addMovieItem(name, link, img_src, '', True, genre, year, cast, director, plot, duration, trailer, None, rating)
    
    if obj_data['more']['start'] != 0:
        params = {'getMoviesByCategory':1,
                  'categoryID':category,
                  'start':obj_data['more']['start']}
        link = util.makeLink(params)
        util.addMenuItem(u'Następne', link, '', setIcon('next'), True, None, '')
    util.endListing()    
      

def getMoviesByActor(params):
    xbmc.executebuiltin('Container.SetViewMode(61)')
    
    actorID = params['actorID']
    start = params['start']
    url = 'http://xbmc.iptvlive.org/getMoviesByActor.php?actorID=' + actorID + '&start=' + start + '&pass=' + PASS + '&email=' + EMAIL
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - IPTVLIVE')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)
    

        
    for s in range(len(obj_data['movies'])):
        name = obj_data['movies'][s]['movieName']
        url = obj_data['movies'][s]['movieURL']
        img_src = obj_data['movies'][s]['movieCover']
        fan_art = obj_data['movies'][s]['movieFanArt']
        genre = obj_data['movies'][s]['movieGenre'],
        year = obj_data['movies'][s]['movieYear'],
        cast = obj_data['movies'][s]['movieCast'],
        director = obj_data['movies'][s]['movieDirector'],
        plot = obj_data['movies'][s]['moviePlot'],
        duration = obj_data['movies'][s]['movieDuration'],
        trailer = obj_data['movies'][s]['movieTrailer'],
        rating = obj_data['movies'][s]['movieRating'],
       
        #caption, link, icon=None, thumbnail=None, folder=False, duration=None, fanart=None
        params = {'play':1,
                  'station':name,
                  'audioUrl':url,
                  'logo':img_src,
                  }
        link = util.makeLink(params)
        #title, link, icon=None, thumbnail=None, folder=False, genre=None, year=None, cast=None, director=None, plot=None, duration=None, trailer=None, fanart=None):
        util.addMovieItem(name, link, img_src, '', True, genre, year, cast, director, plot, duration, trailer, None, rating)
    
    if obj_data['more']['start'] != 0:
        params = {'getMoviesByActor':1,
                  'actorID':actorID,
                  'start':obj_data['more']['start']}
        link = util.makeLink(params)
        util.addMenuItem(u'Następne', link, '', setIcon('next'), True, None, '')
    util.endListing()  
      
      
def searchActor(params):
    searchStr = params['search']
    if searchStr == '0':
      searchStr = ""
      keyboard = xbmc.Keyboard(searchStr,'Search')
      keyboard.doModal()
      searchStr = keyboard.getText().replace(' ','+')  # sometimes you need to replace spaces with + or %20
    
      if (keyboard.isConfirmed() == False):
        return getMoviesCategories()
    
    
    
    if len(searchStr) == 0:
      return getMoviesCategories()
    
    
    url = 'http://xbmc.iptvlive.org/searchActor.php?q=' + searchStr + "&start=" + params['start'] + '&pass=' + PASS + '&email=' + EMAIL
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - IPTVLIVE')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)
      
      
    for s in range(len(obj_data['actors'])):
      name = obj_data['actors'][s]['actorName']
      photo = obj_data['actors'][s]['actorPhoto']
      actorID = obj_data['actors'][s]['actorID']

      #caption, link, icon=None, thumbnail=None, folder=False, duration=None, fanart=None
      params = {'getMoviesByActor':1,'actorID':actorID, 'start':0}
      link = util.makeLink(params)
      #title, link, icon=None, thumbnail=None, folder=False, genre=None, year=None, cast=None, director=None, plot=None, duration=None, trailer=None, fanart=None):
      util.addMenuItem(name, link, photo, photo, True, None,'')
    
    if obj_data['more']['start'] > 0:
        params = {'searchActor':1,
                'search':searchStr,
                'start':obj_data['more']['start']}
        link = util.makeLink(params)
        util.addMenuItem(u'Następne', link, '', setIcon('next'), True, None, '')
    
    util.endListing()
      
      
def searchMovies(params):
    searchStr = params['search']
    if searchStr == '0':
      searchStr = ""
      keyboard = xbmc.Keyboard(searchStr,'Search')
      keyboard.doModal()
      searchStr = keyboard.getText().replace(' ','+')  # sometimes you need to replace spaces with + or %20
    
      if (keyboard.isConfirmed() == False):
        return getMoviesCategories()
    
    
    
    if len(searchStr) == 0:
      return getMoviesCategories()
    
    
    #searchStr = urllib.urlencode(searchStr)
    searchStr = urllib.quote(searchStr)
    url = 'http://xbmc.iptvlive.org/searchMovies.php?q=' + searchStr + "&start=" + params['start'] + '&upass=' + PASS + '&email=' + EMAIL
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - IPTVLIVE')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)
      
      
    for s in range(len(obj_data['movies'])):
      name = obj_data['movies'][s]['movieName']
      url = obj_data['movies'][s]['movieURL']
      img_src = obj_data['movies'][s]['movieCover']
      fan_art = obj_data['movies'][s]['movieFanArt']
      genre = obj_data['movies'][s]['movieGenre'],
      year = obj_data['movies'][s]['movieYear'],
      cast = obj_data['movies'][s]['movieCast'],
      director = obj_data['movies'][s]['movieDirector'],
      plot = obj_data['movies'][s]['moviePlot'],
      duration = obj_data['movies'][s]['movieDuration'],
      trailer = obj_data['movies'][s]['movieTrailer'],
      rating = obj_data['movies'][s]['movieRating'],
      #caption, link, icon=None, thumbnail=None, folder=False, duration=None, fanart=None
      params = {'play':1,
        'station':name,
        'audioUrl':url,
        'logo':img_src,
        }
      link = util.makeLink(params)
      #title, link, icon=None, thumbnail=None, folder=False, genre=None, year=None, cast=None, director=None, plot=None, duration=None, trailer=None, fanart=None):
      util.addMovieItem(name, link, img_src, '', True, genre, year, cast, director, plot, None, trailer, None, rating)
    
    if obj_data['more']['start'] > 0:
        params = {'searchMovies':1,
                'search':searchStr,
                'start':obj_data['more']['start']}
        link = util.makeLink(params)
        util.addMenuItem(u'Następne', link, '', setIcon('next'), True, None, '')
    
    util.endListing()

def radioMainMenu():
    #ddMenuItem(caption, link, icon=None, thumbnail=None, folder=False, duration=None, fanart=None):
    param = {'buildRadioCategories':1}
    link = util.makeLink(param)
    util.addMenuItem('[COLOR red]Gatunki [/COLOR]', link, '', setIcon('Music_Genres'), True, None, '')
    
    
    url = 'http://radio.iptvlive.org/getProviders.php'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - PL RADIO')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)
    
    for s in range(len(obj_data)):
        params = {'radioProviderStations':1,
                  'provider':obj_data[s]['providerName']}
        link = util.makeLink(params)
        name = obj_data[s]['providerName']
        img_src = obj_data[s]['providerLogo']
        util.addMenuItem(name, link, img_src, '', True, None, '')
    
    param = {'radioSearch':1}
    link = util.makeLink(param)
    util.addMenuItem('[COLOR blue]Szukaj [/COLOR]', link, '', setIcon('Music_Genres'), True, None, '')    
    util.endListing()

#Get main page radio categories
def getRadioCategories():
    url = 'http://radio.iptvlive.org/getCategories.php'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - PL RADIO')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'buildRadioCategories':1,
                  'category':obj_data[s]['categoryName'],
                  'logo':obj_data[s]['categoryLogo']}
        link = util.makeLink(params)
        name = obj_data[s]['categoryName']
        img_src = obj_data[s]['categoryLogo']

        util.addMenuItem(name, link, img_src, '', True, None, '')
    
def buildRadioCategories(params):
    url = 'http://radio.iptvlive.org/getCategories.php'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - PL RADIO')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'radioCategoryList':1,
                  'category':obj_data[s]['categoryName']}
        link = util.makeLink(params)
        name = obj_data[s]['categoryName']
        img_src = obj_data[s]['categoryLogo']
        fan_art = obj_data[s]['categoryFanArt']
        print fan_art
        name = name.decode('utf-8')
        util.addMenuItem(name, link, img_src, '', True, None, fan_art)
        
        
    util.endListing()

def radioCategoryList(params):
    category = params['category']
    url = 'http://radio.iptvlive.org/getRadioStations.php?category=' + urllib.quote(category)
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - PL RADIO')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'play':1,
                  'station':obj_data[s]['stationName'],
                  'audioUrl':obj_data[s]['stationURL'],
                  'logo':obj_data[s]['stationLogo']}
        link = util.makeLink(params)
        name = obj_data[s]['stationName']
        img_src = obj_data[s]['stationLogo']
    
        util.addMenuItem(name, link, img_src, '', True, None, '')
        
        
    util.endListing()

def radioProviderStations(params):
    url = 'http://radio.iptvlive.org/getProviderStations.php?provider=' + params['provider']
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - PL RADIO')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'play':1,
                  'station':obj_data[s]['stationName'],
                  'audioUrl':obj_data[s]['stationURL'],
                  'logo':obj_data[s]['stationLogo']}
        link = util.makeLink(params)
        name = obj_data[s]['stationName']
        img_src = obj_data[s]['stationLogo']
        util.addMenuItem(name, link, img_src, '', True, None, '')
        
        
    util.endListing()

def radioSearch(params):
    searchStr = ''
    keyboard = xbmc.Keyboard(searchStr,'Search')
    keyboard.doModal()

    if (keyboard.isConfirmed() == False):
        return mainMenu()
    searchStr = keyboard.getText().replace(' ','+')  # sometimes you need to replace spaces with + or %20
    if len(searchStr) == 0:
        return mainMenu()
    else:
    
        url = 'http://radio.iptvlive.org/search.php?search=' + searchStr
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'XBMC - PL RADIO')
        response = urllib2.urlopen(req)
        obj_data = json.load(response)

        for s in range(len(obj_data)):
            params = {'play':1,
                      'station':obj_data[s]['stationName'],
                      'audioUrl':obj_data[s]['stationURL'],
                      'logo':obj_data[s]['stationLogo']}
            link = util.makeLink(params)
            name = obj_data[s]['stationName']
            img_src = obj_data[s]['stationLogo']
            util.addMenuItem(name, link, img_src, '', True, None, '')
        
        
        util.endListing()
    
def percentage(part, whole):
  return 100 * int(part)/int(whole)

def checkVersion():
  url = 'http://xbmc.iptvlive.org/version.php' 
  req = urllib2.Request(url)
  req.add_header('User-Agent', 'XBMC - IPTVLIVE')
  response = urllib2.urlopen(req)
  obj_data = json.load(response)
  
  addon_version = __addon__.getAddonInfo("version")
  version = obj_data['version'][0]['version']
  
  if addon_version < version:
    dialog.ok(" Używasz starej wersji wtyczki", " Odwiedź http://vip.iptvlive.org aby pobrać nową wersje wtyczki ")
    
#Determine Icon path
def setIcon(icon):
        return os.path.join(tvt.getAddonInfo('path'), "images/") + icon + '.png'

#Main Menu Items
def mainMenuItems():
		checkVersion()
		
		param = {'tv':1}
		link = util.makeLink(param)
		util.addMenuItem('Telewizja', link, '', setIcon('tv'), True, None, '')
				
		param = {'radio':1}
		link = util.makeLink(param)
		util.addMenuItem('Radio', link, '', setIcon('radio'), True, None, '')
				
		#param = {'filmy':1}
		#link = util.makeLink(param)
		#util.addMenuItem('Filmy', link, '', setIcon('movies'), True, None, '')
		
		param = {'options':1}
		link = util.makeLink(param)
		util.addMenuItem('Ustawienia', link, '', setIcon('settings'), True, None, '')
				
		util.endListing()
				
				
#Global Variables    
parameters = util.parseParameters()
CATEGORIES_URL  = 'http://xbmc.iptvlive.org/getCategories.php'




#Main Start of the program
if 'play' in parameters:
    playAudio(parameters)
elif 'categoryTVList' in parameters:
    categoryTVList(parameters)
elif 'tv' in parameters:
    getTVCategories()
elif 'filmy' in parameters:
    getMoviesCategories()
elif 'moviesAlpha' in parameters:
    showAlpha()
elif 'showMoviesByLetter' in parameters:
    showMoviesByLetter(parameters)
elif 'getMoviesByCategory' in parameters:
    getMoviesByCategory(parameters)
elif 'getMoviesByActor' in parameters:
    getMoviesByActor(parameters)
elif 'searchMovies' in parameters:
    searchMovies(parameters)
elif 'searchActor' in parameters:
    searchActor(parameters)
elif 'buildRadioCategories' in parameters:
    buildRadioCategories(parameters)
elif 'radio' in parameters:
    radioMainMenu()
elif 'radioCategoryList' in parameters:
    radioCategoryList(parameters)
elif 'radioProviderStations' in parameters:
    radioProviderStations(parameters)
elif 'radioSearch' in parameters:
    radioSearch(parameters)
elif 'options' in parameters:
    __addon__.openSettings()

else:
    mainMenuItems()
