# -*- coding: utf-8 -*
import util, urllib,urllib2, xbmcplugin, xbmcaddon, xbmcgui, re, sys, os
import json

ADDON_ID = 'plugin.audio.pl.radio'
BASEURL = 'http://radio.iptvlive.org/'

tvt = xbmcaddon.Addon()
pDialog = xbmcgui.DialogProgress()
dialog = xbmcgui.Dialog()

def playAudio(params):
        url = params['audioUrl']
        title = params['station']
        img_src = params['logo']
        
        li = xbmcgui.ListItem(label=title, iconImage=img_src, thumbnailImage=img_src)
        li.setInfo(type='Audio', infoLabels={ "Title": title })
        xbmc.Player().play(item=url, listitem=li)

def search(params):
    print "szukaj"
    searchStr = ''
    keyboard = xbmc.Keyboard(searchStr,'Search')
    keyboard.doModal()
    print 'show keyboard'
    if (keyboard.isConfirmed() == False):
        return mainMenu()
    searchStr = keyboard.getText().replace(' ','+')  # sometimes you need to replace spaces with + or %20
    if len(searchStr) == 0:
        return mainMenu()
    else:
    
        url = 'http://radio.iptvlive.org/search.php?search=' + searchStr
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'XBMC - PL RADIO')
        response = urllib2.urlopen(req)
        obj_data = json.load(response)

        for s in range(len(obj_data)):
            params = {'play':1,
                      'station':obj_data[s]['stationName'],
                      'audioUrl':obj_data[s]['stationURL'],
                      'logo':obj_data[s]['stationLogo']}
            link = util.makeLink(params)
            name = obj_data[s]['stationName']
            img_src = obj_data[s]['stationLogo']
            util.addMenuItem(name, link, img_src, '', True, None, '')
        
        
        util.endListing()


def buildCategories(params):
    url = 'http://radio.iptvlive.org/getCategories.php'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - PL RADIO')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'categoryList':1,
                  'category':obj_data[s]['categoryName']}
        link = util.makeLink(params)
        name = obj_data[s]['categoryName']
        img_src = obj_data[s]['categoryLogo']
        fan_art = obj_data[s]['categoryFanArt']
        print fan_art
        name = name.decode('utf-8')
        util.addMenuItem(name, link, img_src, '', True, None, fan_art)
        
        
    util.endListing()

def categoryList(params):
    category = params['category']
    url = 'http://radio.iptvlive.org/getRadioStations.php?category=' + urllib.quote(category)
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - PL RADIO')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'play':1,
                  'station':obj_data[s]['stationName'],
                  'audioUrl':obj_data[s]['stationURL'],
                  'logo':obj_data[s]['stationLogo']}
        link = util.makeLink(params)
        name = obj_data[s]['stationName']
        img_src = obj_data[s]['stationLogo']
    
        util.addMenuItem(name, link, img_src, '', True, None, '')
        
        
    util.endListing()

def providerStations(params):
    url = 'http://radio.iptvlive.org/getProviderStations.php?provider=' + params['provider']
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - PL RADIO')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'play':1,
                  'station':obj_data[s]['stationName'],
                  'audioUrl':obj_data[s]['stationURL'],
                  'logo':obj_data[s]['stationLogo']}
        link = util.makeLink(params)
        name = obj_data[s]['stationName']
        img_src = obj_data[s]['stationLogo']
        util.addMenuItem(name, link, img_src, '', True, None, '')
        
        
    util.endListing()


def mainMenu():
    #ddMenuItem(caption, link, icon=None, thumbnail=None, folder=False, duration=None, fanart=None):
    param = {'buildCategories':1}
    link = util.makeLink(param)
    util.addMenuItem('[COLOR red]Gatunki [/COLOR]', link, '', setIcon('Music_Genres'), True, None, '')
    
    
    url = 'http://radio.iptvlive.org/getProviders.php'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - PL RADIO')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)
    
    for s in range(len(obj_data)):
        params = {'providerStations':1,
                  'provider':obj_data[s]['providerName']}
        link = util.makeLink(params)
        name = obj_data[s]['providerName']
        img_src = obj_data[s]['providerLogo']
        util.addMenuItem(name, link, img_src, '', True, None, '')
    
    param = {'search':1}
    link = util.makeLink(param)
    util.addMenuItem('[COLOR blue]Szukaj [/COLOR]', link, '', setIcon('Music_Genres'), True, None, '')    
    util.endListing()

#Get main page categories
def getCategories():
    url = 'http://radio.iptvlive.org/getCategories.php'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'XBMC - PL RADIO')
    response = urllib2.urlopen(req)
    obj_data = json.load(response)

    for s in range(len(obj_data)):
        params = {'buildCategories':1,
                  'category':obj_data[s]['categoryName'],
                  'logo':obj_data[s]['categoryLogo']}
        link = util.makeLink(params)
        name = obj_data[s]['categoryName']
        img_src = obj_data[s]['categoryLogo']

        util.addMenuItem(name, link, img_src, '', True, None, '')

#Determine Icon path
def setIcon(icon):
        return os.path.join(tvt.getAddonInfo('path'), "images/") + icon + '.png'


#Global Variables    
parameters = util.parseParameters()
CATEGORIES_URL  = 'http://radio.iptvlive.org/getCategories.php'
BASEURL = 'http://www.nick.com.pl'


#Main Start of the program
if 'play' in parameters:
    playAudio(parameters)
elif 'categoryList' in parameters:
    categoryList(parameters)
elif 'buildCategories' in parameters:
    buildCategories(parameters)
elif 'providerStations' in parameters:
    providerStations(parameters)
elif 'search' in parameters:
    search(parameters)
else:
    mainMenu()
