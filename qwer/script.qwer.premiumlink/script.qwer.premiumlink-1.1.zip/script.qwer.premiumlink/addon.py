import time
import xbmc
import os
import xbmcgui
import urllib2
import webbrowser


def menuoptions():
    dialog = xbmcgui.Dialog()
    funcs = (
        function1,
        function2,
        function3,
        function4,
		function5,
		function6,
		function7,
		function8,
		function9,
        )
        
    call = dialog.select('[B][COLOR=yellow]PREMIUM[/COLOR][COLOR=red] TV LINKS[/COLOR][/B]', [
    '[B][COLOR=white]      pierwsza.tv[/COLOR][/B]', 
    '[B][COLOR=white]      wizja.tv[/COLOR][/B]',
    '[B][COLOR=white]      yoy.tv[/COLOR][/B]',
    '[B][COLOR=white]      weeb.tv[/COLOR][/B]',
	'[B][COLOR=white]      goldvod.tv[/COLOR][/B]',
	'[B][COLOR=white]      pilot.wp.pl[/COLOR][/B]',
	'[B][COLOR=white]      listam3u.com[/COLOR][/B]',
	'[B][COLOR=white]      player.pl[/COLOR][/B]',
	'[B][COLOR=white]      ...[/COLOR][/B]',
	])
    # dialog.selectreturns
    #   0 -> escape pressed
    #   1 -> first item
    #   2 -> second item
    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-9]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()
    
def function1():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://pierwsza.tv/' ) )
    else:
        opensite = webbrowser . open('http://pierwsza.tv/')

def function2():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://wizja.tv/' ) )
    else:
        opensite = webbrowser . open('https://wizja.tv/')
        
def function3():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://yoy.tv/' ) )
    else:
        opensite = webbrowser . open('https://yoy.tv/')
        
def function4():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://weeb.tv/' ) )
    else:
        opensite = webbrowser . open('http://weeb.tv/')
		
def function5():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://goldvod.tv/' ) )
    else:
        opensite = webbrowser . open('http://goldvod.tv/')
		
def function6():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://pilot.wp.pl/tv' ) )
    else:
        opensite = webbrowser . open('https://pilot.wp.pl/tv')
		
def function7():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://listam3u.com/' ) )
    else:
        opensite = webbrowser . open('http://listam3u.com/')
		
def function8():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://player.pl/' ) )
    else:
        opensite = webbrowser . open('https://player.pl/')
		
def function9():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://wp.pl' ) )
    else:
        opensite = webbrowser . open('https://wp.pl')
     
menuoptions()
