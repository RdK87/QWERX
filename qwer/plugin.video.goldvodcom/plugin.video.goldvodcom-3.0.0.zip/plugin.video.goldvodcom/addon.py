import sys, re, os
import urllib, urllib2
import urlparse
import xbmcgui
import xbmcplugin
import xbmc, xbmcaddon
import json

__myurl__ = 'http://goldvod.com'
__scriptID__ = 'plugin.video.goldvodcom'
__addon__ = xbmcaddon.Addon(id='plugin.video.goldvodcom')

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
VERSION = 3.0

xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)

if mode is None:					
    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-filmy.png' )
    url = build_url({'mode': 'filmy', 'foldername': 'Filmy'})
    li = xbmcgui.ListItem('Filmy', iconImage=icon)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-seriale.png' )
    url = build_url({'mode': 'seriale', 'foldername': 'Seriale'})
    li = xbmcgui.ListItem('Seriale', iconImage=icon)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-kabarety.png' )
    url = build_url({'mode': 'kabarety', 'foldername': 'Kabarety'})
    li = xbmcgui.ListItem('Kabarety', iconImage=icon)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-opcje.png' )
    url = build_url({'mode': 'ustawienia', 'foldername': 'Ustawienia'})
    li = xbmcgui.ListItem('Ustawienia', iconImage=icon)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'ustawienia':
    __addon__.openSettings()

elif mode[0] == 'filmy':
    us = __addon__.getSetting('username')
    ps = __addon__.getSetting('userpassword')

    url = 'http://goldvod.com/api/getCategoriesMovie.php'
    headers = { 'User-Agent': 'XBMC', 'ContentType': 'application/x-www-form-urlencoded' }
    post = { 'username': us, 'password': ps }
    data = urllib.urlencode(post)
    reqUrl = urllib2.Request(url, data, headers)
    red_json = urllib2.urlopen(reqUrl)
    obj_data = json.load(red_json)

    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-filmy.png' )
    url = build_url({'mode': 'kategoria', 'idkat': '0'})
    li = xbmcgui.ListItem('Najnowsze 500 filmow [Alfabetycznie A-Z]', iconImage=icon)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)

    for s in range(len(obj_data)):
        url = build_url({'mode': 'kategoria', 'idkat': obj_data[s]['id']})
        li = xbmcgui.ListItem(obj_data[s]['name'], iconImage=icon)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'kategoria':
    us = __addon__.getSetting('username')
    ps = __addon__.getSetting('userpassword')
    idkat = args['idkat'][0]

    url = 'http://goldvod.com/api/getMovies.php'
    headers = { 'User-Agent': 'XBMC', 'ContentType': 'application/x-www-form-urlencoded' }
    post = { 'username': us, 'password': ps, 'id' : idkat }
    data = urllib.urlencode(post)
    reqUrl = urllib2.Request(url, data, headers)
    red_json = urllib2.urlopen(reqUrl)
    obj_data = json.load(red_json)

    if len(obj_data) is 0:
        dialog = xbmcgui.Dialog()
        dialog.ok("Brak konta premium", " Brak aktywnego konta premium.\n Wiecej informacji na http://goldvod.com/pakiet-gold.html")
    else:
        for s in range(len(obj_data)):
            url = obj_data[s]['urlen']
            li = xbmcgui.ListItem(obj_data[s]['title'], iconImage=obj_data[s]['img'])
            li.setInfo('video', {'year': obj_data[s]['year'], 'votes' : obj_data[s]['votes'], 'rating' : obj_data[s]['rate'], 'plot' : obj_data[s]['desc'] })
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'seriale':
    us = __addon__.getSetting('username')
    ps = __addon__.getSetting('userpassword')

    url = 'http://goldvod.com/api/getNameSerials.php'
    headers = { 'User-Agent': 'XBMC', 'ContentType': 'application/x-www-form-urlencoded' }
    post = { 'username': us, 'password': ps }
    data = urllib.urlencode(post)
    reqUrl = urllib2.Request(url, data, headers)
    red_json = urllib2.urlopen(reqUrl)
    obj_data = json.load(red_json)

    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-seriale.png' )
    for s in range(len(obj_data)):
        url = build_url({'mode': 'serial', 'idser': obj_data[s]['id']})
        li = xbmcgui.ListItem(obj_data[s]['name'], iconImage=obj_data[s]['img'])
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'serial':
    us = __addon__.getSetting('username')
    ps = __addon__.getSetting('userpassword')
    idkat = args['idser'][0]

    url = 'http://goldvod.com/api/getSerials.php'
    headers = { 'User-Agent': 'XBMC', 'ContentType': 'application/x-www-form-urlencoded' }
    post = { 'username': us, 'password': ps, 'id' : idkat }
    data = urllib.urlencode(post)
    reqUrl = urllib2.Request(url, data, headers)
    red_json = urllib2.urlopen(reqUrl)
    obj_data = json.load(red_json)

    if len(obj_data) is 0:
        dialog = xbmcgui.Dialog()
        dialog.ok("Brak konta premium", " Brak aktywnego konta premium.\n Wiecej informacji na http://goldvod.com/pakiet-gold.html")
    else:
        icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-kseriale.png' )
        for s in range(len(obj_data)):
            url = obj_data[s]['urlen']
            li = xbmcgui.ListItem(obj_data[s]['title'], iconImage=obj_data[s]['img'])
            li.setInfo('video', {'plot' : obj_data[s]['desc'] })
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'kabarety':
    us = __addon__.getSetting('username')
    ps = __addon__.getSetting('userpassword')

    url = 'http://goldvod.com/api/getNameCabarets.php'
    headers = { 'User-Agent': 'XBMC', 'ContentType': 'application/x-www-form-urlencoded' }
    post = { 'username': us, 'password': ps }
    data = urllib.urlencode(post)
    reqUrl = urllib2.Request(url, data, headers)
    red_json = urllib2.urlopen(reqUrl)
    obj_data = json.load(red_json)

    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-kabarety.png' )
    for s in range(len(obj_data)):
        url = build_url({'mode': 'kabaret', 'idkab': obj_data[s]['id']})
        li = xbmcgui.ListItem(obj_data[s]['name'], iconImage=obj_data[s]['img'])
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'kabaret':
    us = __addon__.getSetting('username')
    ps = __addon__.getSetting('userpassword')
    idkat = args['idkab'][0]

    url = 'http://goldvod.com/api/getCabarets.php'
    headers = { 'User-Agent': 'XBMC', 'ContentType': 'application/x-www-form-urlencoded' }
    post = { 'username': us, 'password': ps, 'id' : idkat }
    data = urllib.urlencode(post)
    reqUrl = urllib2.Request(url, data, headers)
    red_json = urllib2.urlopen(reqUrl)
    obj_data = json.load(red_json)

    if len(obj_data) is 0:
        dialog = xbmcgui.Dialog()
        dialog.ok("Brak konta premium", " Brak aktywnego konta premium.\n Wiecej informacji na http://goldvod.com/pakiet-gold.html")
    else:
        icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-kabarety.png' )
        for s in range(len(obj_data)):
            url = obj_data[s]['urlen']
            li = xbmcgui.ListItem(obj_data[s]['title'], iconImage=obj_data[s]['img'])
            li.setInfo('video', {'plot' : obj_data[s]['desc'] })
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li)

    xbmcplugin.endOfDirectory(addon_handle)
