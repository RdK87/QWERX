import time
import xbmc
import os
import xbmcgui
import urllib2
import webbrowser


def menuoptions():
    dialog = xbmcgui.Dialog()
    funcs = (
        function1,
        function2,
        function3,
        function4,
		function5,
		function6,
		function7,
		function8,
		function9,
        )
        
    call = dialog.select('[B][COLOR=yellow]BUILD[/COLOR][COLOR=red] MAP[/COLOR][/B]', [
    '[B][COLOR=white]      CHERRY TV FB GROUP[/COLOR][/B]', 
    '[B][COLOR=red]      QWER REPO[/COLOR][/B]',
    '[B][COLOR=white]      BUILD MAP[/COLOR][/B]',
    '[B][COLOR=white]      BOX RANKING[/COLOR][/B]',
	'[B][COLOR=white]      kodiapps.com[/COLOR][/B]',
	'[B][COLOR=white]      wirelesshack.org[/COLOR][/B]',
	'[B][COLOR=white]      whyingo.org[/COLOR][/B]',
	'[B][COLOR=white]      technadu.com[/COLOR][/B]',
	'[B][COLOR=white]      BEST TV BOX OD 2017[/COLOR][/B]',
	
	])
    # dialog.selectreturns
    #   0 -> escape pressed
    #   1 -> first item
    #   2 -> second item
    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-9]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()
    
def function1():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.facebook.com/groups/1586232148100741/?ref=group_header' ) )
    else:
        opensite = webbrowser . open('https://www.facebook.com/groups/1586232148100741/?ref=group_header')

def function2():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://meserak86.github.io/QWER/' ) )
    else:
        opensite = webbrowser . open('https://meserak86.github.io/QWER/')
        
def function3():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://meserak86.github.io/QWER/map.txt' ) )
    else:
        opensite = webbrowser . open('https://meserak86.github.io/QWER/map.txt')
        
def function4():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://www.webunit.co.uk/TVBOXES/charts/tvboxchart.html' ) )
    else:
        opensite = webbrowser . open('http://www.webunit.co.uk/TVBOXES/charts/tvboxchart.html')
		
def function5():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://kodiapps.com/builds-chart' ) )
    else:
        opensite = webbrowser . open('https://kodiapps.com/builds-chart')
		
def function6():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://www.wirelesshack.org/' ) )
    else:
        opensite = webbrowser . open('http://www.wirelesshack.org/')
		
def function7():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://whyingo.org/' ) )
    else:
        opensite = webbrowser . open('http://whyingo.org/')
	
def function8():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.technadu.com/kodi/' ) )
    else:
        opensite = webbrowser . open('https://www.technadu.com/kodi/')
	
def function9():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.youtube.com/watch?v=9gx1RAuftG0' ) )
    else:
        opensite = webbrowser . open('https://www.youtube.com/watch?v=9gx1RAuftG0')
		

     
menuoptions()
