# -*- coding: utf-8 -*-

import urllib2,urllib,json
import re,os
from urlparse import urlparse
import base64
import cookielib

BASEURL= "https://www.laczynaspilka.pl/lista-filmow,1.html"
TIMEOUT = 10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'

def getUrl(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)
    if cookies:
        req.add_header("Cookie", cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()
        response.close()
    except:
        link=''
    return link

url="https://www.laczynaspilka.pl/lista-filmow,1.html"
url='https://www.laczynaspilka.pl/lista-filmow,CAYQAA.html'
def getContent(url,**kwargs):
    if not url: url = BASEURL
    content = getUrl(url)
    out=[]
    tds = re.compile('<a (href="//www.youtube.com.*?)</a>',re.DOTALL).findall(content)
    nextPage=False
    prevPage=False
    for td in tds:
        #td = tds[0]
        href = re.compile('href="(.*?)"').findall(td)
        title = re.compile('data-title="(.*?)"').findall(td)
        date = re.compile('data-date="(.*?)"').findall(td)
        img=re.compile('<img src="(.*?)"').findall(td)
        if href and title:
            h = 'http:'+href[0]
            t = title[0].strip()
            i = img[0] if img else ''
            code = date[0] if date else ''
            out.append({'url':h,'title':t,'img':i,'code':code})
    if out:
        nextPage = re.compile('<a href="(http.*?)">Następna').findall(content)
        nextPage = {'urlp': nextPage[0]} if nextPage else False
        prevPage = re.compile('<a href="(http.*?)"> &laquo; Poprzednia').findall(content)
        prevPage = {'urlp': prevPage[0]} if prevPage else False
    return (out,(prevPage,nextPage))  

def getVideos(ex_link):
    return {'msg':'','url':ex_link}
