# -*- coding: utf-8 -*-

import urllib2,urllib,json
import re,os
from urlparse import urlparse
import base64
import cookielib

BASEURL= "http://www.goalsarena.org/"
TIMEOUT = 10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'

def getUrl(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)
    if cookies:
        req.add_header("Cookie", cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()
        response.close()
    except:
        link=''
    return link

#
def getContent(url='',type='latest_highlights',page='1',**kwargs):
    if type == 'latest_highlights':
        return getLATESTHIGHLIGHTS()
    elif type =='must_watch':
        return getMUSTWATCH()
    return [],(False,False)

def getLATESTHIGHLIGHTS():
    content = getUrl('http://www.goalsarena.org/en')
    goalvideos=re.compile('<div class="goalvideos"><h2><span class="flags sprite-\d+"(.*?)</div>',re.DOTALL).findall(content)
    out = []
    for goal in goalvideos:
        # goal = goalvideos[0]
        href_title = re.compile('<a title="(.*?)" href="(.*?)">').findall(goal)
        if href_title:
            out.append({'title':href_title[0][0],'url':href_title[0][1]})
    return out,(False,False)

def getMUSTWATCH():
    content = getUrl('http://www.goalsarena.org/en')
    goalvideos=re.compile('<div class="thumboverlay">(.*?)</div>',re.DOTALL).findall(content)
    out = []
    for goal in goalvideos:
        # goal = goalvideos[0]
        href_img_title = re.compile('<a href="(.*)"><img class="thumbwrapper" src="(.*)" width="170px" height="120px" alt="(.*)"/>').findall(goal)
        if href_img_title:
            out.append({'title':href_img_title[0][2].strip(),'img':href_img_title[0][1],'url':href_img_title[0][0]})
    return out,(False,False)  

#url='http://www.goalsarena.org/en/video/friendly/11-10-2016-usa-new-zealand-friendly.html'
url='http://www.goalsarena.org/en/video/goal-compilation-videos/goals-of-season-2014-2015-so-far.html'
def getVideos(url):
    content = getUrl(url)
    v={'msg':'Video link not found or not supported yet'}
    src = re.compile('data-config="(.*\.json)"').findall(content)
    if src:
        v={'msg':'','url':src[0].replace('player.json','zeus.json')}
    return v        
    
    
def getMain():
    out=[
        {'title':'Latest Highlights','url':'','params':{'type':'latest_highlights','page':1}},
        {'title':'Must Watch','url':'','params':{'type':'must_watch','page':1}},
        ]
    return out
