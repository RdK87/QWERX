# -*- coding: utf-8 -*-
__scriptname__ = "Alltube"
__author__ = "detoyy"
__url__ = ""
__scriptid__ = "plugin.video.alltube"
__credits__ = "Frizbi,Bunkford,mortael,mrknow"
__version__ = "0.1.46"

import sys,os,json
import urllib,urllib2,re
#from t0mm0.common.addon import Addon
from bs4 import BeautifulSoup
import requests
import cfscrape
from time import sleep
import cookielib
import subprocess



import utils,string,unpacker,cookielib,StringIO
import urlresolver

try: import xbmc,xbmcplugin,xbmcgui,xbmcaddon
except:
     xbmc_imported = False
else:
     xbmc_imported = True


#cookie = "__cfduid=d71362c0a979d7cce4ee74c7d784abb971486315124; PHPSESSID=K%2ChtSvqxxf3bsWggBlG-fpevmI8; cookieinfo=1; __gfp_64b=bq_6Dc7xtKMtAxOBL7Y2YN.CpBYkzK8GTKLzyhnGENz.g7; cda.player=html5; __utmt=1; vasty=6; flash_version=Shockwave Flash 24.0 r0; flash=1; SC_unique_220341=0; SC_unique_220269=0; __utma=223312324.1250616798.1486315133.1486315133.1488033967.2; __utmb=223312324.11.10.1488033967; __utmc=223312324; __utmz=223312324.1486315133.1.1.utmcsr=google|utmccn=(organic)|utmcmd=organic|utmctr=(not%20provided); 2017premium-carteblanche=2; 2017premium-carteblanche_2=2"
#cdacookie = urllib.urlencode(cookie)

def getCloudCookie ():
     scraper = cfscrape.create_scraper()
     link = scraper.get("http://alltube.tv/").content
     print link
     return scraper



def getHtml(url,scraper):
        scraper = getCloudCookie ()
        link = scraper.get(url).content
        return link


#get path to me
addon = xbmcaddon.Addon()
download_path = addon.getSetting('use-meta')
alltube=addon.getAddonInfo('path')
rootDir = addon.getAddonInfo('path')
if rootDir[-1] == ';':
    rootDir = rootDir[0:-1]
rootDir = xbmc.translatePath(rootDir)
resDir = os.path.join(rootDir, 'resources')
foldericon = xbmc.translatePath(os.path.join(resDir, 'Folder_Icon.png'))
searchicon = xbmc.translatePath(os.path.join(resDir, 'search.png'))

#_PLT = Addon('plugin.video.alltube', sys.argv)


def xbmcpath(path,filename):
     translatedpath = os.path.join(xbmc.translatePath( path ), ''+filename+'')
     return translatedpath

def _get_keyboard(default="", heading="", hidden=False):
        """ shows a keyboard and returns a value """
        keyboard = xbmc.Keyboard(default, heading, hidden)
        keyboard.doModal()
        if (keyboard.isConfirmed()):
                return unicode(keyboard.getText(), "utf-8")
        return default

def SEARCHVIDEOS(url):
        searchUrl = 'http://alltube.tv/index.php?url=search/autocomplete/&phrase='
        vq = _get_keyboard(heading="Enter the query")
        # if blank or the user cancelled the keyboard, return
        if (not vq): return False, 0
        # we need to set the title to our query
        title = urllib.quote_plus(vq)
        SZUKAJ(searchUrl,title)

def vshareio(url):
    r = requests.get(url)
    #print r
    #print r.text.encode('UTF-8')
    match = re.compile('<source src="(.+?)" type="video/mp4').findall(r.text) #0 - pierwszy link
    #print match[0]+ ' rot13'
    videourl = match[0]
    #rot13 = rot13+'.zc4'
    #videourl = rot13.decode('rot13')
    #posterurl = 'http://alltube.tv/static/host/play.png'
    print videourl+ ' vshareio_videourl'
    return videourl

def CDA(url):
    r = requests.get(url)
    #print r
    #print r.text.encode('UTF-8') 
    match = re.compile("file\":\"(.*?).mp4").findall(r.text)
    print match[0]+ ' rot13'
    rot13 = match[0].replace('\/','/')
    rot13 = rot13+'.mp4'
    videourl = rot13
    #videourl = rot13.decode('rot13')
    posterurl = 'http://alltube.tv/static/host/play.png'
    #videourl = string.translate(videourl, rot13)
    print videourl+ ' cda_videourl'
    return (videourl,posterurl)


def addDir(name,url,mode,iconimage,opis,page):
         #print opis + ' opis'
         #print url + ' url'
         #print name + ' name'
         u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)  + "&opis=" +urllib.quote_plus(opis)+"&page=" + str(page)   
         ok = True
         liz = xbmcgui.ListItem(name, iconImage=foldericon,thumbnailImage=iconimage)                               
         #liz.setInfo(type="Video", infoLabels={ "Title": name })
         liz.setInfo(type='video', infoLabels={'plot':opis,
                    'title': name})#,
                    # 'director': movie["director"],
                    #'plot': (movie["plot"] if "plot" in movie else '') }) 
         liz.addContextMenuItems([ ('Opis filmu', 'XBMC.Action(Info)') ], replaceItems=False)
         ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
         return ok

     
def CATEGORIES():
        addDir('Filmy najnowsze','http://alltube.tv/filmy-online/strona[1]+',6,'','',1)
        addDir('Seriale najnowsze','http://alltube.tv/seriale-online/1',9,'','',1)
        addDir('Kids','http://alltube.tv/filmy-online/kategoria[5]+strona[1]+',2,'','',1)
        addDir('Szukaj filmu/serialu','http://alltube.tv/szukaj',3,searchicon,'','')
        addDir('Filmy wg rodzaju','http://alltube.tv/filmy-online/',5,'','',1)
        addDir('Filmy wg wersji jezykowej','http://alltube.tv/filmy-online/',7,'','',1)
        addDir('Filmy wg roku produkcji','http://alltube.tv/filmy-online/',8,'','',1)
        addDir('Spis seriali','http://alltube.tv/seriale-online/',10,'','',1)
        addDir('Filmiki najnowsze','http://alltube.tv/fun/',13,'','',1)
        addDir('Filmiki wg kategorii','http://alltube.tv/fun/',15,'','',1)




def opis_filmu (url):
          #-----------------    opis filmu ----------------
          url = url#+'#movie-tab'
          opis  = getHtml (url,None)
          print 'opistu: ' + opis
          match=re.compile('<p class="text-justify">(.+?)</p>').findall(str(opis))
          #match=re.compile('<p class="description text-justify">(.+?)</p>').findall(str(opis))
          if match:
               for opis_filmu in match:
                    opis_filmu=string.replace(opis_filmu,'&quot;','')
                    opis_filmu=string.replace(opis_filmu,'&oacute;','o')
                    opis_filmu=string.replace(opis_filmu,'&ndash;','-')
                    opis_filmu=string.replace(opis_filmu,'&rdquo;','')
                    opis_filmu=string.replace(opis_filmu,'&bdquo;','')
                    #print opis_filmu
                    #print opis_filmu + ' opistu'
               #--------------------   opis koniec -------------------
               if opis_filmu:
                    return opis_filmu
               else:
                    return False

def PLAYLISTS (url,page):
        nr_strony = str(page)
        page=page+1
        link = getHtml (url,None)
        soup = BeautifulSoup(link, 'html.parser')
        tags = soup.find_all("div", {"class":"col-sm-6"})
        for tag in tags:
                      links = tag.find_all('a')
                      wersja = ""
                      tytul = tag.find("h3")
                      tytul = tytul.text
                      opis = tag.find("p")
                      opis = opis.text
                      print tytul.encode('UTF-8')
                      imglinks = tag.find_all('img')
                      for imglink in imglinks:
                           imgfullLink = imglink.get('src').strip()
                      print imgfullLink

                      for link in links:
                           fullLink = link.get('href').strip()
                           #opis = opis_filmu(fullLink)
                           #if opis :
                           addDir('[COLOR yellow]'+tytul.encode('UTF-8')+'[/COLOR] ('+opis.encode('UTF-8')+' )',fullLink.encode('UTF-8'),14,imgfullLink,opis.encode('UTF-8'),'')
        addDir('Next page -----> str.' +str(page),url+str(page) ,13,'','',page) 

     
def FILMIKI(url,page):
        nr_strony = str(page)
        page=page+1
        link = getHtml (url,None)
        soup = BeautifulSoup(link, 'html.parser')
        tags = soup.find_all("div", {"class":"col-xs-12 col-md-6"})
        for tag in tags:
                      links = tag.find_all('a')
                      wersja = ""
                      tytul = tag.find("h3")
                      tytul = tytul.text
                      opis = tag.find("p")
                      opis = opis.text
                      print tytul.encode('UTF-8')
                      imglinks = tag.find_all('img')
                      for imglink in imglinks:
                           imgfullLink = imglink.get('src').strip()
                      print imgfullLink

                      for link in links:
                           fullLink = link.get('href').strip()
                           #opis = opis_filmu(fullLink)
                           #if opis :
                           addDir('[COLOR yellow]'+tytul.encode('UTF-8')+'[/COLOR] ('+opis.encode('UTF-8')+' )',fullLink.encode('UTF-8'),14,imgfullLink,opis.encode('UTF-8'),'')
        addDir('Next page -----> str.' +str(page),url+str(page) ,13,'','',page) 

def FILMIKI_KAT(url,page):
        link = getHtml (url,None)
        soup = BeautifulSoup(link, 'html.parser')

        divTag = soup.find_all("ul", {"class":"text-white list-unstyled default-list"})
        #print divTag
        for ul in divTag:
                match=re.compile('<li><a href="(.+?)">(.+?)</a></li>').findall(str(ul))
                for url,nazwa_kategorii in match:
                        print url+' '+nazwa_kategorii
                        addDir(nazwa_kategorii,url,13,'','',str(page))        

def KIDS(url,page):
        #http://alltube.tv/filmy-online/kategoria[5]+strona[1]+
        nextpage = url.replace('['+ str(page) +']+','') 
        #nr_strony = str(page)
        page=page+1
        nextpage = nextpage+'['+str(page)+']+'
        print nextpage + 'bajkinext'
        link = getHtml (url,None)
        soup = BeautifulSoup(link, 'html.parser')
        divTag = soup.find_all("div", {"class":"col-xs-12 col-sm-6 col-lg-3"})
        for tag in divTag:
             print tag
             match=re.compile('<div class="item-details">(\d\d\d\d)\s\S+\s<i aria-hidden="true" class="fa fa-microphone"></i>\s(.*)\s\S+\s<i aria-hidden="true" class="fa fa-eye"></i>\s\d+</div>').findall(str(tag))
             for rok , lang in match:
                    rok = rok
                    lang_wer = lang
             print ''
             tytul = tag.find("h3")
             tytul = tytul.text
             link = tag.find('a')
             fullLink = link.get('href').strip()
             if addon.getSetting("100") == "true":
                    opis=opis_filmu(fullLink)
                    if opis:
                         opis = str(opis)
                    else :
                         opis = " Sorry: nieudane pobieranie opisu "
             else:
                 opis = "aby pobierac opisy filmów zmień ustawienia wtyczki"                       #opis = opis_filmu(fullLink)

             imglinks = tag.find_all('img')
             #opis = opis_filmu(fullLink)
             for imglink in imglinks:
                  imgfullLink = imglink.get('src').strip()
             tytul = tytul + ' (' + rok + ') ' + '[COLOR blue]' + lang_wer + '[/COLOR]'
             addDir(tytul.encode('UTF-8')+' ',fullLink.encode('UTF-8'),4,imgfullLink,opis,'')
        #nexturl = 'http://alltube.tv/dla-dzieci/strona['+str(page)+']+'
        addDir('Next page -----> str.'+str(page),nextpage,2,'','',page)  # mode 2 bo jak mode 6 to inne divy

def SZUKAJ(url,query):
        headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Origin': 'http://alltube.tv',
        'Accept-Encoding':'gzip, deflate',
        'Accept': 'application/json, text/javascript, */*; q=0.01'
        }
        print query + ' query'
        url = url+query
        content = requests.get(url, headers=headers)
        parsed_json = json.loads(content.text)
        wyniki = parsed_json['suggestions']
        for item in wyniki:
              #print  item['value']
              name = item['value']
              #print  item['data']
              url = item['data']

              if "/serial/" in url:
                  print url + ' seriall'
                  addDir(name.encode('UTF-8')+'[COLOR yellow] - Serial[/COLOR]',url,12,'','',1)
              elif "/filmik/" in url:
                  addDir(name.encode('UTF-8')+'[COLOR red] - Filmiki[/COLOR]',url,14,'','',1)
              elif "/aktor/" in url:
                  print ''        
              else:
                   if addon.getSetting("100") == "true":
                         opis=opis_filmu(url)
                         if opis:
                              opis = str(opis)
                         else :
                              opis = " Sorry: nieudane pobieranie opisu "
                   else:
                       opis = "aby pobierac opisy filmów zmień ustawienia wtyczki"                       #opis = opis_filmu(fullLink)
                   addDir(name.encode('UTF-8'),url,4,'',opis,1)
     
def WGRODZAJU(url,page):
        link = getHtml (url,None)
        soup = BeautifulSoup(link, 'html.parser')

        divTag = soup.find_all("ul", {"class":"filter-list filter-category"})
        #print divTag
        for ul in divTag:
                match=re.compile('<li data-id="(\d+)" data-popular="\d">(.+?)</li>').findall(str(ul))
                for kategoria_id,nazwa_kategorii in match:
                        #print kategoria_id+' '+nazwa_kategorii
                        #print url+'kategoria['+kategoria_id+']+strona['+str(page)+']+ tututu'
                        addDir(nazwa_kategorii,url+'kategoria['+kategoria_id+']+strona['+str(page)+']+',6,'','',str(page))

def FILMY(url,page,scraper):
        print url + ' kategoriaa'
        #http://alltube.tv/filmy-online/kategoria[49]+strona[1]+
        #http://alltube.tv/filmy-online/kategoria[5]+strona[1]+
        #http://alltube.tv/filmy-online/strona[1]+
        nextpage = url.replace('['+ str(page) +']+','')                    
        #nr_strony = str(page)
        page=page+1
        nextpage = nextpage+'['+str(page)+']+'
        print nextpage + ' nextt'
        link = getHtml( url,scraper)
        #print link
        wersja = ""
        soup = BeautifulSoup(link, 'html.parser')
        tags = soup.find_all("div", {"class":"col-xs-12 col-sm-6 col-lg-4"})
        for tag in tags:
                  #print tag
                  match=re.compile('<div class="item-details">(\d\d\d\d)\s\S+\s<i aria-hidden="true" class="fa fa-microphone"></i>\s(.*)\s\S+\s<i aria-hidden="true" class="fa fa-eye"></i>\s\d+</div>').findall(str(tag))
                  for rok , lang in match:
                       rok = rok
                       lang_wer = lang
                  links = tag.find_all('a')
                  for link in links:
                       fullLink = link.get('href').strip()
                       print fullLink + ' fulll'
                       if addon.getSetting("100") == "true":
                              #opis=opis_filmu(fullLink)
                              opis = "cloudflare problem "
                              if opis:
                                   opis = str(opis)
                              else :
                                   opis = " Sorry: nieudane pobieranie opisu "
                       else:
                              opis = "aby pobierac opisy filmów zmień ustawienia wtyczki"                       #opis = opis_filmu(fullLink)
                  imglinks = tag.find_all('img')
                  for imglink in imglinks:
                      imgfullLink = imglink.get('src').strip()
                      print imgfullLink
                  tytul = tag.find("h3")
                  tytul = tytul.text
                  tytul = tytul + ' (' + rok + ') ' + '[COLOR blue]' + lang_wer + '[/COLOR]'
                  print tytul.encode('UTF-8')
                  match=re.compile('<p class="text-justify" style="display: none; padding-right: 15px; font-size: 0\.9em;">(.+?)<\/p>').findall(str(tag))
                  for opis in match:
                       opis = str(opis)
                  if addon.getSetting("100") == "true": #18+ checked
                       addDir(tytul.encode('UTF-8')+' '+wersja,fullLink.encode('UTF-8'),4,imgfullLink,opis,'')
                  else:
                       if not 'allerotico.png' in imgfullLink:
                            addDir(tytul.encode('UTF-8')+' '+wersja,fullLink.encode('UTF-8'),4,imgfullLink,opis,'')
        addDir('Next page -----> str.'+str(page),nextpage,6,'','',page)          


def WGLANGVER(url,page):
        link = getHtml (url,None)
        soup = BeautifulSoup(link, 'html.parser')

        divTag = soup.find_all("ul", {"class":"filter-list","id":"filter-version"})
        #print divTag
        for ul in divTag:
                match=re.compile('<li data-id="(.+?)">(.+?)</li>').findall(str(ul))
                for kategoria_id,nazwa_kategorii in match:
                        print kategoria_id+' '+nazwa_kategorii
                        url_kategoria_id = url+'kategoria[]+wersja['+kategoria_id+']+strona[1]'
                        print "kategoriaa "+url_kategoria_id
                        addDir(nazwa_kategorii.encode('UTF-8'),url_kategoria_id.encode('UTF-8'),6,'','',str(page))

def WGROKU(url,page):
        link = getHtml (url,None)
        soup = BeautifulSoup(link, 'html.parser')

        divTag = soup.find_all("ul", {"class":"filter-list","id":"filter-year"})
        #print divTag
        for ul in divTag:
                match=re.compile('<li data-id="(.+?)">(.+?)</li>').findall(str(ul))
                for kategoria_id,nazwa_kategorii in match:
                        #print kategoria_id+' '+nazwa_kategorii
                        addDir(nazwa_kategorii,url+'rok['+kategoria_id+']+strona[1]',6,'','',str(page))

def SERIALE(url,page):
        nr_str = str(page)
        page= page+1
        link = getHtml (url,None)
        soup = BeautifulSoup(link, 'html.parser')

        #print(soup.prettify())
        #print(soup.body)
        divTag = soup.find_all("div",{"class":"col-xs-12 col-sm-2"})
        #print divTag
        for tag in divTag:
                 imglinks = tag.find_all('img')
                 for imglink in imglinks:
                        imgfullLink = imglink.get('src').strip()
                        print imgfullLink + ' imgfull'
                 links = tag.find_all('a')
                 wersja = ""
                 for link in links:
                         fullLink = link.get('href').strip()
                         print fullLink + ' fulll'
                 tytul = tag.find("div", {"class":"top-belt"})
                 tytul = tytul.text
                 ostatni = tag.find("div", {"class":"bottom-belt"})
                 ostatni = ostatni.text
                 addDir(tytul.encode('UTF-8')+' [COLOR=blue]'+ostatni.encode('UTF-8')+'[/COLOR]',fullLink,12,imgfullLink,'',page)
        nexturl=url.replace('/'+nr_str,'')
        nexturl = 'http://alltube.tv/seriale-online/'+str(page)
        addDir('Next page -----> str.'+str(page),nexturl,9,'','',page)  

def SERIALE_SPIS(url,page):
        link = getHtml (url,None)
        soup = BeautifulSoup(link, 'html.parser')
        divTag = soup.find_all("li", {"class":"letter"})
        #print divTag
        for tag in divTag:
               letter = tag.text.encode('UTF-8')
               if not "&" in letter:
                    print letter + ' litery'
                    addDir(letter,url,11,'','',str(page))

def INDEX11(url,letter,page):
        link = getHtml (url,None)
        print letter + ' litera'
        match = re.compile('<li data-letter="'+str(letter)+'"><a href="(.+?)">(.+?)</a></li>').findall(link)
        for adres,tytul in match:
               addDir(tytul,adres.encode('UTF-8'),12,'','',str(page))

def SEZONY(url,page):
	link = getHtml (url,None)
	soup = BeautifulSoup(link, 'html.parser')
	divTag = soup.find_all("ul", {"class":"episode-list"})
	sSezon='brak'
	for tag in divTag:
		print ''
		divTags2 = tag.find_all("li", {"class":"episode"})
		for tag in divTags2:
			links = tag.find_all('a')
			for link in links:
				fullLink = link.get('href').strip()
				match =re.compile('-sezon-(.+?)/',re.I).findall(fullLink) 
				if sSezon != match[0]:
					sSezon=match[0]
					addDir('[COLOR  yellow]Sezon '+sSezon+'[/COLOR]',fullLink,16,'','',sSezon)

def ODCINKI(url,page):
	link = getHtml (url,None)
	soup = BeautifulSoup(link, 'html.parser')
	divTag = soup.find_all("ul", {"class":"episode-list"})
	for tag in divTag:
		print ''
		divTags2 = tag.find_all("li", {"class":"episode"})
		for tag in divTags2:
			links = tag.find_all('a')
			for link in links:
				fullLink = link.get('href').strip()
				name = re.compile('odcinek-(.+?)-sezon-',re.I).findall(fullLink)
				if '/' in name[0]:
					odcinek,reszta = name[0].split('/',1)
				else:
					odcinek = name[0]
				match =re.compile('-sezon-(.+?)/',re.I).findall(fullLink) 
				if match[0]==str(page):
					addDir('[COLOR  yellow]Sezon '+match[0]+'[/COLOR] [COLOR white]odc. '+odcinek+'[/COLOR]',fullLink,4,'','',str(page))
        

                        
def VIDEOLINKS(url,name):
	name = name.replace('[COLOR green]Lektor','')
	name = name.replace('[COLOR orange]Napisy','')
	#name = name.replace('[/COLOR]','')
	link = getHtml(url,None)
	cHost=name[name.find(" [COLOR deepskyblue]<")+22:name.find(">[/COLOR] ")]
	print cHost+"$"+url
	soup = BeautifulSoup(link, 'html.parser')
	tr = soup.find_all("tr")
	for tr in tr:
             lang = re.compile('<td class="text-center" style="width: 80px;">(.+?)</td>').findall(str(tr))
             print lang[0] + ' langg'
             divTag = tr.find_all("a" ,{"class":"watch"})    
             #print divTag
             for tag in divTag:
		match=re.compile('<a class="watch" data-iframe="(.+?)" href="#!">Oglądaj</a>').findall(str(tag))
		for zakodowane in match:
                        
			#print zakodowane + " linki"
			url = zakodowane.decode('base64')
			print url+":"+cHost
			if cHost in url:
				if 'openload' in url:
                                     check = getHtml ('https://openload.co/',None)
                                     if not '503 Service Unavailable' in check:  # jezeli openload działa 
					host = 'openload'
					if 'alltube' in url :
                                             video_id = url.replace('http://alltube.tv/special.php?hosting=openload&id=','')
                                        if 'kinex' in url :
                                             video_id = url.replace('http://kinex.tv/special.php?hosting=openload&id=','')
					#media_url = "http://openload.io/embed/"+video_id+"/"
					media_url = "https://openload.co/f/"+video_id+"/"
					ref = media_url
					#img_source = utils.getHtml(media_url, '', utils.openloadhdr)
					#match = re.compile('<meta name="og:image" content="(.+?)">').findall(img_source)
					#try:
						#poster_url = match[0]
					#except Exception:
						#pass
					print media_url + ' mediaurl'
					poster_url = 'http://alltube.tv/static/host/openload.png'
					#media_url = utils.playvideo(media_url, 'name', '','')
					hmf = urlresolver.HostedMediaFile(url=media_url)
                                        if hmf:
                                              print 'yay! we can resolve this one'
                                        else:
                                              print 'sorry :( no resolvers available to handle this one.'
                                        media_url = urlresolver.HostedMediaFile(url=media_url).resolve()
					#media_url = urlresolver(media_url)
					#media_url = media_url+'|User-Agent=Mozilla/5.0 (Windows NT 10.0; WOW64; rv:44.0) Gecko/20100101 Firefox/44.0&Referer='+ref
					print str(media_url) + ' referer'
				if 'nowvideo' in url:
                                     media_url = url
                                     poster_url = 'http://alltube.tv/static/host/nowvideo.png'
                                     media_url = urlresolver.resolve(media_url)
                                     
				else:
					match= re.compile('http:\/\/alltube\.tv\/special\.php\?hosting=(.+?)&id=(.*)').findall(url)                 
					for host, video_id in match:
						print host + ' hostingi'
						#host = host.replace('embed.','')
						#host = host.replace('www.','')
						if "cda" in host:
							print video_id + ' videoid'
							ref = 'http://static.cda.pl/flowplayer/flash/flowplayer.commercial-3.2.18.swf'
							url = "http://ebd.cda.pl/740x487/" + video_id
							#poster_url = 'http://alltube.tv/static/host/play.png'
							media_url,poster_url = CDA(url)
							if media_url:
								#media_url = media_url+'|referer=http://static.cda.pl/flowplayer/flash/flowplayer.commercial-3.2.18.swf'
								#media_url = media_url+'|Cookie=PHPSESSID=1&Referer=http://static.cda.pl/flowplayer/flash/flowplayer.commercial-3.2.18.swf'
								#media_url = media_url + '|Cookie=' + cdacookie + '|&Referer=' + ref
								media_url = media_url+'|Cookie=PHPSESSID=1&Referer=' + ref


								print media_url
						elif "streamin" in host:
							media_url = "http://streamin.to/"+video_id
							media_url = urlresolver.resolve(media_url)
							poster_url = 'http://alltube.tv/static/host/streamin.png'
						elif "streamango" in host:
							media_url = "http://streamango.com/embed/"+video_id
							media_url = urlresolver.resolve(media_url)
							poster_url = 'http://alltube.tv/static/host/streamango.png'
						elif "streamcherry" in host:
							media_url = "https://www.streamcherry.com/embed/"+video_id
							media_url = urlresolver.resolve(media_url)
							poster_url = 'http://alltube.tv/static/host/streamcherry.png'
						elif "rapidvideo" in host:
							media_url = "https://www.rapidvideo.com/embed/"+video_id
							media_url = urlresolver.resolve(media_url)
							poster_url = 'http://alltube.tv/static/host/rapidvideo.png'

						elif "vidlox" in host:
							media_url = "https://vidlox.tv/embed-"+video_id+".html"
							media_url = urlresolver.resolve(media_url)
							poster_url = 'http://alltube.tv/static/host/vidlox.png'
						elif "vidzi" in host:
							media_url = "http://vidzi.tv/embed-"+video_id+"-495x357.html"
							media_url = urlresolver.resolve(media_url)
							poster_url = 'http://alltube.tv/static/host/vidzi.png'
						elif "vidto" in host:
							media_url = "http://vidto.me/" + video_id + '.html'
							media_url = urlresolver.resolve(media_url)
							poster_url = 'http://alltube.tv/static/host/play.png'
						elif "vshare" in host:
							#media_url = "http://vshare.io/d/" + video_id
							media_url = "http://vshare.io/v/" + video_id + "/width-620/height-280/" 
                                                        media_url = vshareio(media_url)
							poster_url = 'http://alltube.tv/static/host/vshare.png'
						elif "youtube" in host:
							media_url = "https://www.youtube.com/watch?v=" + video_id
                 					hmf = urlresolver.HostedMediaFile(url=media_url)
                                                        if hmf:
                                                             print 'yay! we can resolve this one'
                                                        else:
                                                             print 'sorry :( no resolvers available to handle this one.'
                                                        media_url = urlresolver.HostedMediaFile(url=media_url).resolve()
							poster_url = 'http://alltube.tv/static/host/youtube.png'
						else:
							try:
								#media_url = urlresolver.resolve(url)
								#poster_url = 'http://alltube.tv/static/host/play.png'
								host = " nieobsugiwany host"
							except Exception:
								pass
                        	if media_url:
                                        
					addLink(name+'[COLOR blue] '+str(lang[0])+'[/COLOR]',media_url,poster_url)
				
def VIDEOHOSTS(urlo,name):
	page=0
	name = name.replace('[COLOR green]Lektor','')
	name = name.replace('[COLOR orange]Napisy','')
	name = name.replace('[COLOR  yellow]','')
	name = name.replace('[COLOR white]','')
	name = name.replace('[/COLOR]','')
	link = getHtml (urlo,None)
	if 'Ten materiał nie posiada żadnych linków.' in link:
             print ' nie posiada'
             addDir(' [COLOR red]Sorry - ten material nie posiada zadnych linkow ...[/COLOR][COLOR green] Milego Dnia .[/COLOR] ',urlo,17,'','',page)
        else:
             soup = BeautifulSoup(link, 'html.parser')
             divTag = soup.find_all("a" ,{"class":"watch"})
	
             hosts=''
             for tag in divTag:
                print tag
		match=re.compile('<a class="watch" data-iframe="(.+?)" href="#!">Oglądaj</a>').findall(str(tag))
		for zakodowane in match: 
			url = zakodowane.decode('base64')
			print 'url: '+ url + ' :url'
			if 'openload' in url:
				host = 'openload'
				if host not in hosts:
					addDir(name+' [COLOR deepskyblue]<'+host+'>[/COLOR] ',urlo,17,'','',page)
					hosts=hosts+host
			if 'nowvideo' in url:
				host = 'nowvideo'
				if host not in hosts:
					addDir(name+' [COLOR deepskyblue]<'+host+'>[/COLOR] ',urlo,17,'','',page)
					hosts=hosts+host
			else:
				match= re.compile('http:\/\/alltube\.tv\/special\.php\?hosting=(.+?)&id=(.*)').findall(url)                 
				host = 'brak'
				for host, video_id in match:
					print host + ' hostingi'
					if "cda" in host:
						if host not in hosts:
							addDir(name+' [COLOR deepskyblue]<'+host+'>[/COLOR] ',urlo,17,'','',page)
							hosts=hosts+host
					elif "vidlox" in host:
						if host not in hosts:
							addDir(name+' [COLOR deepskyblue]<'+host+'>[/COLOR] ',urlo,17,'','',page)
							hosts=hosts+host
					elif "vidzi" in host:
						if host not in hosts:
							addDir(name+' [COLOR deepskyblue]<'+host+'>[/COLOR] ',urlo,17,'','',page)
							hosts=hosts+host
					elif "streamin" in host:
						if host not in hosts:
							addDir(name+' [COLOR deepskyblue]<'+host+'>[/COLOR] ',urlo,17,'','',page)
							hosts=hosts+host
					elif "vidto" in host:
						if host not in hosts:
							addDir(name+' [COLOR deepskyblue]<'+host+'>[/COLOR] ',urlo,17,'','',page)
							hosts=hosts+host
					elif "vshare" in host:
						if host not in hosts:
							addDir(name+' [COLOR deepskyblue]<'+host+'>[/COLOR] ',urlo,17,'','',page)
							hosts=hosts+host
					elif "youtube" in host:
						if host not in hosts:
							addDir(name+' [COLOR deepskyblue]<'+host+'>[/COLOR] ',urlo,17,'','',page)
							hosts=hosts+host
					elif "streamango" in host:
						if host not in hosts:
							addDir(name+' [COLOR deepskyblue]<'+host+'>[/COLOR] ',urlo,17,'','',page)
							hosts=hosts+host
					elif "streamcherry" in host:
						if host not in hosts:
							addDir(name+' [COLOR deepskyblue]<'+host+'>[/COLOR] ',urlo,17,'','',page)
							hosts=hosts+host
					elif "rapidvideo" in host:
						if host not in hosts:
							addDir(name+' [COLOR deepskyblue]<'+host+'>[/COLOR] ',urlo,17,'','',page)
							hosts=hosts+host
					else:
						try:
							host = " nieobsugiwany host"
						except Exception:
							pass


def FILMIKI_iframe(url,name):
        link = getHtml (url,None)
        match= re.compile('<iframe width="\d\d\d" height="\d\d\d" src="(.+?)" frameborder="0" allowfullscreen><\/iframe>').findall(link)
        for yt in match:
             media_url = urlresolver.resolve(yt)
             addLink(name ,media_url,'http://alltube.tv/static/host/play.png')
               
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                print params + " parametry"
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                               
        return param

def addLink(name,url,iconimage):
        ok=True
        win = xbmcgui.Window(10000)
        win.setProperty('1ch.playing.title', name)
        win.setProperty('1ch.playing.year', '2069')
        #win.setProperty('pltv.playing.imdb', )
        win.setProperty('1ch.playing.season', name[2:3])
        win.setProperty('1ch.playing.episode', name[5:6])
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable","true") # bez tego nie dziala youtube
        #print 'totu'+str(url)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        return ok
    
params=get_params()
url=None
name=None
mode=None
season=None
scraper=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass
try:
        cookie=urllib.unquote_plus(params["scraper"])
except:
        pass


print "Mode : "+str(mode)
#print "URL: "+str(url)
#print "Name: "+str(name)
#print "Season: "+str(season)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        #print "hmmm "+url
        INDEX(url)

elif mode==2:
        print "mode kids "+url
        KIDS(url,page)
        
elif mode == 3:
        print mode
        SEARCHVIDEOS(url)
            
elif mode==4:
        #print ""+url
        VIDEOHOSTS(url,name)

elif mode==5:
        #print ""+url
        WGRODZAJU(url,page)

elif mode==6:
        #print ""+url
        FILMY(url,page,scraper)
        
elif mode==7:
        #print ""+url
        WGLANGVER(url,page)

elif mode==8:
        #print ""+url
        WGROKU(url,page)

elif mode==9:
        #print ""+url
        SERIALE(url,page)

elif mode==10:
        #print "mode 10 start "+url
        SERIALE_SPIS(url,page)

elif mode==11:
        #print "mode 11 start"
        INDEX11(url,name,page)

elif mode==12:
        #print ""+url
        SEZONY(url,page)
elif mode==13:
        #print ""+url
        FILMIKI(url,page)
elif mode==14:
        #print ""+url
        FILMIKI_iframe(url,name)
elif mode==15:
        #print ""+url
        FILMIKI_KAT(url,page)
elif mode==16:
     ODCINKI(url,page)
elif mode==17:
     VIDEOLINKS(url,name)
elif mode==18:
     PLAYLISTS(url,page)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
