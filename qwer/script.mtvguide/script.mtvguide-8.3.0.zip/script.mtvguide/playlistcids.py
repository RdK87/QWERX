#      Copyright (C) 2018 Mariusz Brychcy
#      Copyright (C) 2016 Andrzej Mleczko

import urllib, copy, re
import xbmc, xbmcgui, xbmcvfs
from strings import *
from serviceLib import *

serviceName   = 'playlist'

class PlaylistUpdater(baseServiceUpdater):
    def __init__(self, instance_number):
        self.serviceName        = serviceName + "_%s" % instance_number
        self.instance_number    = str(instance_number)
        self.localMapFile       = 'playlistmap.xml'
        baseServiceUpdater.__init__(self)
        self.servicePriority    = int(ADDON.getSetting('%s_priority' % self.serviceName))
        self.serviceDisplayName = ADDON.getSetting('%s_display_name' % self.serviceName)
        self.source             = ADDON.getSetting('%s_source'       % self.serviceName)
        self.addDuplicatesToList = True
        self.useOnlineMap       = False

        if int(instance_number) <= int(ADDON.getSetting('nr_of_playlists')):
            self.serviceEnabled  = ADDON.getSetting('%s_enabled'     % self.serviceName)
        else:
            self.serviceEnabled = 'false'

        if self.source == 'Url':
            self.url = ADDON.getSetting('%s_url' % self.serviceName)
        else:
            self.url = xbmc.translatePath(ADDON.getSetting('%s_file' % self.serviceName))

        if ADDON.getSetting('%s_high_prio_hd' % self.serviceName) == 'true':
            self.hdStreamFirst = True
        else:
            self.hdStreamFirst = False

        if ADDON.getSetting('%s_stop_when_starting' % self.serviceName) == 'true':
            self.stopPlaybackOnStart = True
        else:
            self.stopPlaybackOnStart = False        

    def getPlaylistContent(self, path, urltype):
        content = ''
        try:
            self.log('getPlaylistContent opening playlist: %s, urltype: %s' % (path, urltype))
            if urltype == 'Url':
                tmpcontent = self.sl.getJsonFromExtendedAPI(path)
                if tmpcontent is None or tmpcontent == '':
                    raise Exception
            else:
                try:
                    tmpcontent = open(path, 'r').read()
                except:
                    self.log('getPlaylistContent opening normally Error %s, type: %s, url: %s' % (getExceptionString(), urltype, path) )
                    self.log('getPlaylistContent trying to open file using xbmcvfs')
                    lf = xbmcvfs.File(path)
                    tmpcontent = lf.read()
                    lf.close()
                    if tmpcontent is None or tmpcontent == "":
                        raise Exception

            content = tmpcontent
        except:
            self.log('getPlaylistContent opening Error %s, type: %s, url: %s' % (getExceptionString(), urltype, path) )
            xbmcgui.Dialog().notification(strings(59905).encode('utf-8'), strings(57049).encode('utf-8') + ' ' + self.serviceName + ' (' + self.getDisplayName() + ') ' + strings(57050).encode('utf-8'), time=10000, sound=False)
        return content

    def getChannelList(self, silent):
        result = list()
        try:
            regexReplaceList = list()

            sdList = list()
            hdList = list()
            fhdList = list()

            cleanup_regex      =     re.compile("\[COLOR\s*\w*\]|\[/COLOR\]|\[B\]|\[/B\]|\[I\]|\[/I\]|^\s*|\s*$",  re.IGNORECASE)

            regexReplaceList.append( re.compile('[^A-Za-z0-9+/:]+',                                                re.IGNORECASE) )
            regexReplaceList.append( re.compile('(\s|^)(pl/en|PL|Polska|Poland|Europe|SD|ADULT:|PL:|VIP:|VIP|Backup|VIASAT:)(?=\s|$)',  re.IGNORECASE) )

            if ADDON.getSetting('showCroatianChannels') == 'true':
                regexReplaceList.append( re.compile('(\s|^)(CRO:|CRO|HR:|HR|HRV:|HRV|Hrvatska|SRB:|SRB|Srbija|BH:|BH|Bosna|SLO:|SLO|Slovenija|SR:|SR|Crna\s*Gora)(?=\s|$)',  re.IGNORECASE) )

            if ADDON.getSetting('showDanishChannels') == 'true':
                regexReplaceList.append( re.compile('(\s|^)(Danmark|Denmark|DK:|Nordic|Scandinavia)(?=\s|$)',      re.IGNORECASE) )

            if ADDON.getSetting('showEnglishChannels') == 'true':
                regexReplaceList.append( re.compile('(\s|^)(UK:)(?=\s|$)',                                         re.IGNORECASE) )

            if ADDON.getSetting('showFrenchChannels') == 'true':
                regexReplaceList.append( re.compile('(\s|^)(FR:)(?=\s|$)',                                         re.IGNORECASE) )

            if ADDON.getSetting('showNorwegianChannels') == 'true':
                regexReplaceList.append( re.compile('(\s|^)(Norge|Norway|NO:|Nordic|Scandinavia)(?=\s|$)',         re.IGNORECASE) )

            if ADDON.getSetting('showSerbianChannels') == 'true':
                regexReplaceList.append( re.compile('(\s|^)(CRO:|CRO|HR:|HR|HRV:|HRV|Hrvatska|SRB:|SRB|Srbija|BH:|BH|Bosna|SLO:|SLO|Slovenija|SR:|SR|Crna\s*Gora)(?=\s|$)',  re.IGNORECASE) )

            if ADDON.getSetting('showSwedishChannels') == 'true':
                regexReplaceList.append( re.compile('(\s|^)(Sverige|Sweden|SE:|Nordic|Scandinavia)(?=\s|$)',       re.IGNORECASE) )

            regexHD            =     re.compile('(\s|^)(720p|720|HD\sHD|HD)(?=\s|$)',                              re.IGNORECASE)
            regexFHD           =     re.compile('(\s|^)(FHD|UHD|1080p|1080|4K)(?=\s|$)',                           re.IGNORECASE)

            regex_chann_name   =     re.compile('tvg-id="[^"]*"',                                                  re.IGNORECASE)
            regexCorrectStream =     re.compile('^http|^rtmp',                                                     re.IGNORECASE)

            #regexRemoveList = list()
            #regexRemoveList.append( re.compile('(\s|^)(ARB|SN|NG|ZA|ML|AFR|CM|KE|GH|GA|BJ|AO|TD|CG|SO|AL|AE|YE|ES|DK|DE|RS|FR|SE|NL|IT|CH|TR|MA|QA|EG|LB|SA|AT|BE|BG|FI|HR|LAM|MX|KRD|IQ|IN|NO|PT|RO|RU|JO|DZ|KW|TN|LE|LY|OM|SY|CZ|EE|BH|GR|TH|IS|PK|BF|GN|EE|Yu|MN|SL|SI|HU|IR|AR|HN|CR|MK|MT|LU|AZ|CA|IL|SAC|AF|BD|UA|19\d\d|20\d\d|CZ/HU|RO/HU|S\s*\d\d\s*E\s*\d\d|UK|US)\s*$', re.IGNORECASE) )

            title = None
            nextFreeCid = 0
            self.log('\n\n')
            self.log('[UPD] Pobieram liste dostepnych kanalow dla serwisu %s' % self.serviceName)
            self.log('[UPD] -------------------------------------------------------------------------------------')
            self.log('[UPD] %-10s %-35s %-35s' % ( '-CID-', '-NAME-', '-STREAM-'))

            channelsArray = self.getPlaylistContent(self.url.strip(), self.source)

            if channelsArray is not None and channelsArray != "" and len(channelsArray) > 0:
                cleaned_playlist = cleanup_regex.sub('', channelsArray)
                for line in cleaned_playlist.splitlines():
                    stripLine = line.strip()

                    if '#EXTINF:' in stripLine:
                        tmpTitle = ''
                        title = ''
                        splitedLine = stripLine.split(',')
                        if len(splitedLine) > 1:
                            tmpTitle = splitedLine[len(splitedLine) - 1].strip()
                        if tmpTitle == '':
                            match = regex_chann_name.findall(stripLine)
                            if len(match) > 0:
                                tmpTitle = match[0].replace("tvg-id=","").replace('"','').strip()

                        if tmpTitle is not None and tmpTitle != '':
                            title = tmpTitle
                            HDStream = False
                            FHDStream = False

                            for regexReplace in regexReplaceList:
                                title = regexReplace.sub(' ', title)

                            title, match = regexFHD.subn(' HD ', title)
                            if match > 0:
                                FHDStream = True

                            title, match = regexHD.subn(' HD ', title)
                            if match > 0:
                                HDStream = True

                            #for regexRemove in regexRemoveList:
                                #if( regexRemove.search(title) ):
                                    #title = ''
                            title = title.replace('  ', ' ').strip()


                    elif title is not None and regexCorrectStream.match(stripLine):
                        if title != '':
                            channelCid = str(nextFreeCid)
                            if FHDStream:
                                channelCid = channelCid + '_FHD'
                                fhdList.append(TvCid(channelCid, title, title, stripLine, ''))
                            elif HDStream:
                                channelCid = channelCid + '_HD'
                                hdList.append(TvCid(channelCid, title, title, stripLine, ''))
                            else:
                                sdList.append(TvCid(channelCid, title, title, stripLine, ''))

                            self.log('[UPD] %-10s %-35s %-35s' % (channelCid, title, stripLine))
                            nextFreeCid = nextFreeCid + 1
                        else:
                            self.log('[UPD] %-10s %-35s %-35s' % ('-', 'No title!', stripLine))

            if self.hdStreamFirst:
                result = fhdList
                result.extend(hdList)
                result.extend(sdList)
            else:
                result = sdList
                result.extend(hdList)
                result.extend(fhdList)

        except Exception, ex:
            self.log('getChannelList Error %s' % getExceptionString())
        return result

    def getChannelStream(self, chann):
        try:
            if self.stopPlaybackOnStart and xbmc.Player().isPlaying():
                xbmc.Player().stop()
                xbmc.sleep(500)
            self.log('getChannelStream: found matching channel: cid %s, name %s, stream %s' % (chann.cid, chann.name, chann.strm))
            return chann

        except Exception, ex:
            self.log('getChannelStream Error %s' % getExceptionString())
        return None

    def log(self, message):
        if self.thread is not None and self.thread.is_alive() and self.forcePrintintingLog == False:
            self.traceList.append(self.__class__.__name__ + '_' + self.instance_number + ' ' + message)
        else:
            deb(self.__class__.__name__ + '_' + self.instance_number + ' ' + message)