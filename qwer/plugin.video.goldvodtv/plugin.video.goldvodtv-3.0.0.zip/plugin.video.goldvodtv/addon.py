﻿import sys, re, os
import urllib, urllib2
import urlparse
import xbmcgui
import xbmcplugin
import xbmc, xbmcaddon
import json

# -*- coding: utf-8 -*-

__myurl__ = 'http://goldvod.tv'
__scriptID__ = 'plugin.video.goldvodtv'
__addon__ = xbmcaddon.Addon(id='plugin.video.goldvodtv')

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
VERSION = 3.1

xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)

if mode is None:
    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-tv.png' )
    url = build_url({'mode': 'tv', 'foldername': 'Telewizja WSZYSTKIE'})
    li = xbmcgui.ListItem('Telewizja WSZYSTKIE', iconImage=icon)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)	

    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-online.png' )
    url = build_url({'mode': 'tv_online', 'foldername': 'Telewizja ONLINE'})
    li = xbmcgui.ListItem('Telewizja ONLINE', iconImage=icon)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)	
								
    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-offline.png' )
    url = build_url({'mode': 'tv_offline', 'foldername': 'Telewizja OFFLINE'})
    li = xbmcgui.ListItem('Telewizja OFFLINE', iconImage=icon)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)									

    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-ulubione.png' )
    url = build_url({'mode': 'ulubione', 'foldername': 'Ulubione'})
    li = xbmcgui.ListItem('Ulubione', iconImage=icon)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)								

    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-opcje.png' )
    url = build_url({'mode': 'ustawienia', 'foldername': 'Ustawienia'})
    li = xbmcgui.ListItem('Ustawienia', iconImage=icon)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'tv':
    us = __addon__.getSetting('username')
    ps = __addon__.getSetting('userpassword')
    lc = __addon__.getSetting('userlocation')
    pr = __addon__.getSetting('userport')

    url = 'http://185.35.139.177/api/index.php?page=get_tv_channels'
    headers = { 'User-Agent': 'XBMC', 'ContentType': 'application/x-www-form-urlencoded' }
    post = { 'login': us, 'pass': ps, 'location': lc, 'port': pr }
    data = urllib.urlencode(post)
    reqUrl = urllib2.Request(url, data, headers)
    red_json = urllib2.urlopen(reqUrl)
    obj_data = json.load(red_json)
    
    foldername = args['foldername'][0]
    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-tv.png' )
    if len(obj_data) is 0:
        dialog = xbmcgui.Dialog()
        dialog.ok("Brak konta premium", " Brak aktywnego konta premium lub brak programów na wybranej liście.\n Wiecej informacji na http://goldvod.tv/pakiet-gold.html")
    else:
        for s in range(len(obj_data)):
            
            ico = obj_data[s]['icon']
            li = xbmcgui.ListItem(obj_data[s]['name'], iconImage=ico, thumbnailImage=ico)
            li.addContextMenuItems([ ('Dodaj do ulubionych', 'XBMC.RunPlugin(%s?mode=add_fav&id_tv=%s)' % (sys.argv[0], obj_data[s]['id'])) ], replaceItems=True)
            
            url = build_url({'mode': 'channel', 'foldername': obj_data[s]['name'], 'id_tv': obj_data[s]['id']})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
				
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'tv_online':
    us = __addon__.getSetting('username')
    ps = __addon__.getSetting('userpassword')
    lc = __addon__.getSetting('userlocation')
    pr = __addon__.getSetting('userport')

    url = 'http://185.35.139.177/api/index.php?page=get_tv_channels'
    headers = { 'User-Agent': 'XBMC', 'ContentType': 'application/x-www-form-urlencoded' }
    post = { 'login': us, 'pass': ps, 'location': lc, 'port': pr, 'type': 'online' }
    data = urllib.urlencode(post)
    reqUrl = urllib2.Request(url, data, headers)
    red_json = urllib2.urlopen(reqUrl)
    obj_data = json.load(red_json)

    foldername = args['foldername'][0]
    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-tv.png' )
    if len(obj_data) is 0:
        dialog = xbmcgui.Dialog()
        dialog.ok("Brak konta premium", " Brak aktywnego konta premium lub brak programów na wybranej liście.\n Wiecej informacji na http://goldvod.tv/pakiet-gold.html")
    else:
        for s in range(len(obj_data)):
            ico = obj_data[s]['icon']
            li = xbmcgui.ListItem(obj_data[s]['name'], iconImage=ico, thumbnailImage=ico)
            li.addContextMenuItems([ ('Dodaj do ulubionych', 'XBMC.RunPlugin(%s?mode=add_fav&id_tv=%s)' % (sys.argv[0], obj_data[s]['id'])) ], replaceItems=True)

            url = build_url({'mode': 'channel', 'foldername': obj_data[s]['name'], 'id_tv': obj_data[s]['id']})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'tv_offline':
    us = __addon__.getSetting('username')
    ps = __addon__.getSetting('userpassword')
    lc = __addon__.getSetting('userlocation')
    pr = __addon__.getSetting('userport')
	
    url = 'http://185.35.139.177/api/index.php?page=get_tv_channels'
    headers = { 'User-Agent': 'XBMC', 'ContentType': 'application/x-www-form-urlencoded' }
    post = { 'login': us, 'pass': ps, 'location': lc, 'port': pr, 'type': 'offline' }
    data = urllib.urlencode(post)
    reqUrl = urllib2.Request(url, data, headers)
    red_json = urllib2.urlopen(reqUrl)
    obj_data = json.load(red_json)

    foldername = args['foldername'][0]
    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-tv.png' )
    if len(obj_data) is 0:
        dialog = xbmcgui.Dialog()
        dialog.ok("Brak konta premium", " Brak aktywnego konta premium lub brak programów na wybranej liście.\n Wiecej informacji na http://goldvod.tv/pakiet-gold.html")
    else:
        for s in range(len(obj_data)):
            ico = obj_data[s]['icon']
            li = xbmcgui.ListItem(obj_data[s]['name'], iconImage=ico, thumbnailImage=ico)
            li.addContextMenuItems([ ('Dodaj do ulubionych', 'XBMC.RunPlugin(%s?mode=add_fav&id_tv=%s)' % (sys.argv[0], obj_data[s]['id'])) ], replaceItems=True)

            url = build_url({'mode': 'channel', 'foldername': obj_data[s]['name'], 'id_tv': obj_data[s]['id']})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'channel':
    us = __addon__.getSetting('username')
    ps = __addon__.getSetting('userpassword')
    lc = __addon__.getSetting('userlocation')
    pr = __addon__.getSetting('userport')
    idtv = args['id_tv'][0]
	
    url = 'http://185.35.139.177/api/index.php?page=get_tv_channel'
    headers = { 'User-Agent': 'XBMC', 'ContentType': 'application/x-www-form-urlencoded' }
    post = { 'login': us, 'pass': ps, 'location': lc, 'port': pr, 'id':idtv }
    data = urllib.urlencode(post)
    reqUrl = urllib2.Request(url, data, headers)
    red_json = urllib2.urlopen(reqUrl)
    obj_data = json.load(red_json)

    foldername = args['foldername'][0]
    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-tv.png' )
    if obj_data['status'] is False:
        dialog = xbmcgui.Dialog()
        dialog.ok("Brak konta premium", " Brak kanału. Spróbuj ponownie.")
    else:
        ico = obj_data['icon']
        url = obj_data['url_sd']
        li = xbmcgui.ListItem(obj_data['name'] + " - SD", iconImage=ico, thumbnailImage=ico)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li)
        if len(obj_data['url_hd']) is not 0:
            url = obj_data['url_hd']
            li = xbmcgui.ListItem(obj_data['name'] + " - HD", iconImage=ico, thumbnailImage=ico)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li)
    xbmcplugin.endOfDirectory(addon_handle)
	
elif mode[0] == 'add_fav':
    us = __addon__.getSetting('username')
    ps = __addon__.getSetting('userpassword')
    idtv = args['id_tv'][0]
    url = 'http://185.35.139.177/api/index.php?page=add_favourite_tv_channel'
    headers = { 'User-Agent': 'XBMC', 'ContentType': 'application/x-www-form-urlencoded' }
    post = { 'login': us, 'pass': ps, 'id': idtv }
    data = urllib.urlencode(post)
    reqUrl = urllib2.Request(url, data, headers)
    red_json = urllib2.urlopen(reqUrl)
    '''obj_data = json.load(red_json)
    sts = obj_data[0]['status']'''

elif mode[0] == 'del_fav':
    us = __addon__.getSetting('username')
    ps = __addon__.getSetting('userpassword')
    idtv = args['id_tv'][0]
    url = 'http://185.35.139.177/api/index.php?page=del_favourite_tv_channel'
    headers = { 'User-Agent': 'XBMC', 'ContentType': 'application/x-www-form-urlencoded' }
    post = { 'login': us, 'pass': ps, 'id': idtv }
    data = urllib.urlencode(post)
    reqUrl = urllib2.Request(url, data, headers)
    red_json = urllib2.urlopen(reqUrl)
    '''obj_data = json.load(red_json)
    sts = obj_data[0]['status']'''
	
elif mode[0] == 'ulubione':
    us = __addon__.getSetting('username')
    ps = __addon__.getSetting('userpassword')

    url = 'http://185.35.139.177/api/index.php?page=get_tv_channels_favourites'
    headers = { 'User-Agent': 'XBMC', 'ContentType': 'application/x-www-form-urlencoded' }
    post = { 'login': us, 'pass': ps }
    data = urllib.urlencode(post)
    reqUrl = urllib2.Request(url, data, headers)
    red_json = urllib2.urlopen(reqUrl)
    obj_data = json.load(red_json)

    foldername = args['foldername'][0]
    icon = os.path.join( __addon__.getAddonInfo('path'), 'images/icon-tv.png' )
    if len(obj_data) is 0:
        dialog = xbmcgui.Dialog()
        dialog.ok("Brak konta premium", " Brak aktywnego konta premium.\n Wiecej informacji na http://goldvod.tv/pakiet-gold.html")
    else:
        for s in range(len(obj_data)):
            url = obj_data[s]['url_sd']
            ico = obj_data[s]['icon']
            li = xbmcgui.ListItem(obj_data[s]['name'], iconImage=ico, thumbnailImage=ico)
            li.addContextMenuItems([ ('Usun z ulubionych', 'XBMC.RunPlugin(%s?mode=del_fav&id_tv=%s)' % (sys.argv[0], obj_data[s]['id'])) ], replaceItems=True)

            url = build_url({'mode': 'channel', 'foldername': obj_data[s]['name'], 'id_tv': obj_data[s]['id']})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'ustawienia':
    __addon__.openSettings()
